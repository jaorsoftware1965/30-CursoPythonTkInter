# Curso de Python - Tkinter
# A01 Ventana Inicial

# El Desarrollo de Interfaces Gráficas de Usuario; GUI's; con Python, es posible realizarlo a través
# de su Librería o Módulo Natural, llamado tkinter; o a través de otras librerías externas como son
# wxPython, PyQt y JPython.

# Este curso está basado en el desarrollo de Interfaces utilizando la librería nativa de Python tkinter.
# Tkinter es la librería Standar para desarrollo de GUI's en Python, la cual a través de su Módulo, 
# provee una completa librería con programación orientada a objetos, que trabaja sobre Tcl/tk.

# Tcl/Tk es una librería gratuita, open source; que permite desarrollar elementos básicos para la 
# construcción de Interfaces Gráficas; la cual se encuentra disponible para muchos lenguajes de 
# programación.

# En este curso se dedicará al conocimiento y programación de cada uno de estos elementos básicos
# que son indispensables en el desarrollo de una interfaz gráfica.

# A continuación se presenta la estructura básica de una aplicación con tkinter

# Se importa la librería; Nota. en Python 2 era Tkinter; ahora; en Python 3 es tkinter
import tkinter

# Llamamos con la librería al método Tk() que lo que hace es construir una ventana principal
# y asignamos esta funcón a una variable; la cual será el que el controle el objeto
top = tkinter.Tk()

# Despliegua la Ventana y ejecuta el loop principal que controla la aplicación
top.mainloop()

print("Finalizó el programa")