# Curso de Python - Tkinter
# A10 Entry II

# En esta clase veremos algunos métodos funcionales para el widget Entry como
# lo son eliminar texto, posicionar el cursor; seleccionar texto.

# Opciones de Desarrollo de un Aplicación

# ----------------------------------------
# Agenda de Consultorio Médico
# Control de Comandas de Restaurante
# Punto de Venta
# Sugerida por los Usuario
# ----------------------------------------

# Se desarrollará la que mas votos tenga

# Se importa la Librería
from tkinter import *

# La Ventana Principal
vPrincipal = Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("A10 Entry II")

# Se establece un tamaño
vPrincipal.geometry("150x280")

# Función para Eliminar 1er Caracter
def fnEliminar():    
    txtPrueba.delete(1)

# Función para Eliminar Todos los Caracteres
def fnEliminarAll():    
    txtPrueba.delete(0,len(txtPrueba.get()))

# Función para Seleccionar Todos los Caracteres
def fnSeleccionar():    
    txtPrueba.select_range(0,len(txtPrueba.get()))

# Función para DesSeleccionar
def fnDesSeleccionar():    
    txtPrueba.select_clear()

# Funcipon para colocar el Cursor
def fnColocaCursor():    
    txtPrueba.icursor(3)

# Función para Selecconar hasta
def fnSeleccionarHasta():    
    txtPrueba.select_adjust(3)

# Función para Verificar Selección
def fnVerificaSel():    
    print(txtPrueba.selection_present())

# Crea un Texto de Entrada
txtPrueba = Entry(vPrincipal)

# Ubica el Control en la Pantalla
txtPrueba.place(x = 20,y = 20)
               
# Crea el Botón de Eliminar
btnEliminar = Button(vPrincipal,                   # Ventana Padre
                     command = fnEliminar,         # Función a ejecutar
                     text = "Eliminar 1er")            # Texto del Botón

# Ubica el Botón de Eliminar
btnEliminar.place(x=20, y = 50)

# Crea el Botón de Eliminar Todo el Texto
btnEliminarAll = Button(vPrincipal,                   # Ventana Padre
                        command = fnEliminarAll,      # Función a ejecutar
                        text = "Eliminar Todos")      # Texto del Botón

# Ubica el Botón de Eliminar Todo
btnEliminarAll.place(x=20, y = 80)



# Crea el Botón de Seleccionar
btnSeleccionar = Button(vPrincipal,                   # Ventana Padre
                        command = fnSeleccionar,      # Función a ejecutar
                        text = "Seleccionar")         # Texto del Botón

# Ubica el Botón de Seleccionar
btnSeleccionar.place(x=20, y = 110)

# Crea el Botón de Desseleccionar
btnDesSeleccionar = Button(vPrincipal,               # Ventana Padre
                    command = fnDesSeleccionar,      # Función a ejecutar
                    text = "DesSeleccionar")         # Texto del Botón

# Ubica el Botón de DesSeleccionar
btnDesSeleccionar.place(x=20, y = 140)

# Crea el Botón de Colocar Cursor
btnColocaCursor = Button(vPrincipal,                # Ventana Padre
                         command = fnColocaCursor,  # Función a ejecutar
                         text = "Colocar Cursor")   # Texto del Botón

# Ubica el Botón de Colocar el Cursor
btnColocaCursor.place(x=20, y = 170)

# Crea el Botón de Seleccionar Hasta
btnSeleccionarHasta = Button(vPrincipal,                    # Ventana Padre
                             command = fnSeleccionarHasta,  # Función a ejecutar
                             text = "Seleccionar Hasta")    # Texto del Botón

# Ubica el Botón de Seleccionar Hasta
btnSeleccionarHasta.place(x=20, y = 200)

# Crea el Botón de Verificar Selección
btnVerificaSel = Button(vPrincipal,                    # Ventana Padre
                              command = fnVerificaSel,       # Función a ejecutar
                              text = "Verifica Sel")         # Texto del Botón

# Ubica el Botón de Verificar
btnVerificaSel.place(x=20, y = 230)

# El Loop Principal
vPrincipal.mainloop()

