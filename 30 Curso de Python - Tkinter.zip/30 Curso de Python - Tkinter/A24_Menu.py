# Curso de Python - Tkinter
# A24 Menu

# Importamos la librería
from tkinter import *

# Función que Procesa Menu
def fnProcesaMenu():
   
   # Crea una ventana
   ventanaTop = Toplevel()
   
   # Crea un boton
   boton = Button(ventanaTop, text="Procesando Menu")
   
   # Lo ubica en la nueva ventana
   boton.pack()

# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A24 Menu")

# Se establece un tamaño
vPrincipal.geometry("600x400")
   
# Creamos la barra del Menu en vPrincipal
menubar = Menu(vPrincipal)

# Creamos un Menu para File
filemenu = Menu(menubar, tearoff = 0)

# Crea las opciones
filemenu.add_command(label = "Crear", command = fnProcesaMenu)
filemenu.add_command(label = "Abrir", command = fnProcesaMenu)
filemenu.add_command(label = "Guardar", command = fnProcesaMenu)
filemenu.add_command(label = "Guardar como...", command = fnProcesaMenu)
filemenu.add_command(label = "Cerrar", command = fnProcesaMenu)

# Añade un Separador
filemenu.add_separator()

# Añade la opción Salidaa y la asocia a un comando
filemenu.add_command(label = "Salir", command = vPrincipal.quit)

# Asocia el Menu a la Barra
menubar.add_cascade(label = "Archivo", menu = filemenu)

# Crea el Menu de Edición
editmenu = Menu(menubar, tearoff=0)

# Añade las opciones
editmenu.add_command(label = "Deshacer", command = fnProcesaMenu)

# Añade un separador
editmenu.add_separator()

# Añade mas opciones
editmenu.add_command(label = "Cortar", command = fnProcesaMenu)
editmenu.add_command(label = "Copiar", command = fnProcesaMenu)
editmenu.add_command(label = "Pegar", command = fnProcesaMenu)
editmenu.add_command(label = "Borrar", command = fnProcesaMenu)
editmenu.add_command(label = "Seleccionar todo", command = fnProcesaMenu)

# Añade el Menu a la barra
menubar.add_cascade(label = "Edicion", menu = editmenu)

# Crea el Menu de Ayuda
helpmenu = Menu(menubar, tearoff=0)

# Agrega las opciones
helpmenu.add_command(label = "Help Index", command = fnProcesaMenu)
helpmenu.add_command(label = "About...", command = fnProcesaMenu)

# Agrega el Menu a la Barra
menubar.add_cascade(label = "Ayuda", menu = helpmenu)

# Agrega a la ventana principal la Barra de Menu
vPrincipal.config(menu = menubar)        

# Procesamiento de la ventana principal 
vPrincipal.mainloop()