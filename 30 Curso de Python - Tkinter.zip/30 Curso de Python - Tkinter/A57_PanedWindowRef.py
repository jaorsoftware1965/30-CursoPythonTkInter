# Curso de Python - Tkinter
# A57 PanedWindow Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A57 PanedWindow Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Constructor
# PanedWindow(parent, option, ...)

# Propiedades para option
# bg or background          The background color displayed behind 
#                           the child widgets
# bd or borderwidth         Width of the border around the outside 
#                           of the widget
# cursor                    The cursor to be displayed when the 
#                           mouse is over the widget.
# handlepad                 Use this option to specify the distance 
#                           between the handle and the end of the
#                           sash. For orient=tk.VERTICAL, this is 
#                           the distance between the left end of
#                           the sash and the handle; for orient=
#                           tk.HORIZONTAL, it is the distance between
#                           the top of the sash and the handle. The 
#                           default value is eight pixels; for other
#                           values.
# handlesize                Use this option to specify the size of the 
#                           handle, which is always a square
# height                    Specifies the height of the widget. If you
#                           don't specify this option, the height is 
#                           determined by the height of the child
#                           widgets.
# opaqueresize              This option controls how a resizing operation
#                           works. For the default value, opaqueresize=
#                           True, the resizing is done continuously as the 
#                           sash is dragged.
#                           If this option is set to False, the sash (and 
#                           adjacent child widgets) stays put until the 
#                           user releases the mouse button, and then it 
#                           jumps to the new position.
# orient                    To stack child widgets side by side, 
#                           use orient=tk.HORIZONTAL. To stack them
#                           top to bottom, use orient=tk.VERTICAL.
# relief                    Selects the relief style of the border around 
#                           the widget. The default is tk.FLAT.
# sashpad                   Use this option to allocate extra space
#                           on either side of each sash. The default 
#                           is zero.
# sashrelief                This option specifies the relief style used 
#                           to render the sashes
# sashwidth                 Specifies the width of the sash. The default
#                           width is two pixels.
# showhandle                Use showhandle=True to display the handles.
#                           For the default value, False, the user can 
#                           still use the mouse to move the sashes. The 
#                           handle is simply a visual cue.
# width                     Width of the widget. If you don't specify
#                           a value, the width will be determined by 
#                           the sizes of the child widgets.

# Métodos

# .add(child[, option=value] ...)
# Use this method to add the given child widget as the next child of this PanedWindow. First create
# the child widget with the PanedWindow as its parent widget, but do not call the .grid()
# method to register it. Then call .add(child) and the child will appear inside the PanedWindow
# in the next available position.
# Associated with each child is a set of configuration options that control its position and appearance.
# See Section 19.1, “PanedWindow child configuration options” (p. 67). You can supply these configuration
# options as keyword arguments to the .add() method. You can also set or change their
# values anytime with the .paneconfig() method, or retrieve the current value of any of these
# options using the .panecget() method; these methods are described below.

# .forget(child)
# Removes a child widget.

# .identify(x, y
# For a given location (x, y) in window coordinates, this method returns a value that describes the
# feature at that location.
# • If the feature is a child window, the method returns an empty string.
# • If the feature is a sash, the method returns a tuple (n, 'sash') where n is 0 for the first sash,
# 1 for the second, and so on.
# • If the feature is a handle, the method returns a tuple (n, 'handle') where n is 0 for the first
# handle, 1 for the second, and so on.

# .panecget(child, option)
# This method retrieves the value of a child widget configuration option, where child is the child
# widget and option is the name of the option as a string. 

# .paneconfig(child, option=value, ...)
# Use this method to configure options for child widgets. The options are described in Section 19.1,
# “PanedWindow child configuration options” (p. 67).

# .panes()
# This method returns a list of the child widgets, in order from left to right (for orient=tk.HORIZONTAL)
# or top to bottom (for orient=tk.VERTICAL).

# .remove(child)
# Removes the given child; this is the same action as the .forget() method.

# .sash_coord(index)
# This method returns the location of a sash. The index argument selects the sash: 0 for the sash
# between the first two children, 1 for the sash between the second and third child, and so forth. The
# result is a tuple (x, y) containing the coordinates of the upper left corner of the sash.

# .sash_place(index, x, y)
# Use this method to reposition the sash selected by index (0 for the first sash, and so on). The x and
# y coordinates specify the desired new position of the upper left corner of the sash. Tkinter ignores
# the coordinate orthogonal to the orientation of the widget: use the x value to reposition the sash
# for orient=tk.HORIZONTAL, and use the y coordinate to move the sash for option orient=
# tk.VERTICAL.

   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
        pwInterna.config(sashwidth=10)    
        pwPrincipal.config(sashwidth=10)  
            
    if (estado==2):
        pwInterna.config(sashpad=5)
        pwPrincipal.config(sashpad=5)
           
    if (estado==3):       
        pwInterna.config(showhandle=True)
        pwPrincipal.config(showhandle=True)
         
    if (estado==4):           
        pwInterna.remove(escala)            
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

# Crea el panedWindow
pwPrincipal = PanedWindow(vPrincipal,
                          bg="GREEN")

# Especifica la forma en que se empacan los objetos
pwPrincipal.pack(fill = BOTH, expand = 1)

# Crea un control de Entrada y lo agrega
txtDatos = Entry(pwPrincipal, bd = 5)
pwPrincipal.add(txtDatos)

# Crea otra pw
pwInterna = PanedWindow(pwPrincipal, 
                        orient = VERTICAL,
                        bg="red")

# La agrega a la paned window principal                        
pwPrincipal.add(pwInterna)

# Crea un objeto escala y lo agrega a la Interna
escala = Scale( pwInterna, orient = HORIZONTAL)
pwInterna.add(escala)

# Crea el botón de Aceptar y lo agrega a la Interna
btnAceptar = Button(pwInterna, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
# Lo agrega
pwInterna.add(btnAceptar) 
                      
# Ejecuta loop
vPrincipal.mainloop()