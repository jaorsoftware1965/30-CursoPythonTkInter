# Curso de Python - Tkinter
# A20 Text

# Un objeto text te permite capturar gran cantidad de
# texto como en un Editor

# Importamos la librería
from tkinter import *

# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A20 Text")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Creamos un texto agregándolo a la ventana principal
text = Text(bg="green")

# Agregamos texto al objeto en la posición actual
text.insert(INSERT, "Hello.....")

# Agregamos texto al final
text.insert(END, "Bye Bye.....")

# Hacemo pack del Objeto
text.pack()

# Añadimos etiquetas
text.tag_add("here", "1.0", "1.4")
text.tag_add("start", "1.10", "1.17")

# Establecemos  configuración para las etiquetas añadidas
text.tag_config("here", background = "yellow", foreground = "blue")
text.tag_config("start", background = "blue", foreground = "yellow")

# Función KeyPress Clave
def fnKeyPressClave(key):        
    print(key.keycode)
    print(key.char)
    if (key.keycode==27):
        vPrincipal.destroy()
        
# Asocia al objeto el control del Evento Key
text.bind("<Key>", fnKeyPressClave)

# Procesamiento de la ventana principal 
vPrincipal.mainloop()