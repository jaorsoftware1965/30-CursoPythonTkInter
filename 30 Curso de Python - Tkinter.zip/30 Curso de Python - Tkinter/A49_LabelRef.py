# Curso de Python - Tkinter
# A49 Label Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A49 Label Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Creación
# Label(parent, option, ...)

# Propiedades
# activebackground      Background color to be displayed when the
#                       mouse is over the widget.
# activeforeground      Foreground color to be displayed when the 
#                       mouse is over the widget
# anchor                This options controls where the text is 
#                       positioned if the widget has more
#                       space than the text needs. The default is
#                       anchor=tk.CENTER, which centers the text 
#                       n the available space. For example, if you
#                       use anchor=tk.NW, the text would be
#                       positioned in the upper left-hand corner
#                       of the available space.
# bg or background      The label's background color
# bitmap                Set this option equal to a bitmap or image
#                       object and the label will display that 
#                       graphic
# bd or borderwidth     Width of the labels's border. The default 
#                       is 2 pixels.
# cursor                The cursor used when the mouse is over 
#                       the label widget
# disabledforeground    The foreground color to be displayed when
#                       the widget's state is tk.DISABLED.
# font                  If you are displaying text in this label 
#                       (with the text or textvariable option, 
#                       the font option specifies in what font 
#                       that text will be displayed.
# fg or foreground      If you are displaying text or a bitmap in
#                       this label, this option specifies the
#                       color of the text. If you are displaying 
#                       a bitmap, this is the color that will fg 
#                       or foreground appear at the position of 
#                       the 1-bits in the bitmap.
# height                Height of the label in lines (not pixels!). 
#                       If this option is not set, the label will 
#                       be sized to fit its contents.
# highlightbackground   Color of the focus highlight when the 
#                       label does not have focus. 
# highlightcolor        Color shown in the focus highlight when 
#                       the label has the focus.
# highlightthickness    Thickness of the focus highlight.
# image                 To display a static image in the label
#                       set this option to an image object 
# justify               Specifies how multiple lines of text will
#                       be aligned with respect to each other: 
#                       tk.LEFT for flush left, tk.CENTER for 
#                       centered (the default), or tk.RIGHT for 
#                       right-justified widget, 
# padx                  Extra space added to the left and right 
#                       of the text within the widget. 
#                       Default is 1.
# pady                  Extra space added to above and top 
#                       of the text within the widget. 
#                       Default is 1.
# relief                Specifies the appearance of a decorative
#                       border around the label. The default is 
#                       tk.FLAT
# state                 By default, an Entry widget is in the 
#                       tk.NORMAL state. Set this option to 
#                       tk.DISABLED to make it unresponsive to 
#                       mouse events. The state will be tk.ACTIVE
#                       when the mouse is over the widget.
# takefocus             Normally, focus does not cycle through 
#                       Label widgets;if you want this widget to 
#                       be visited by the focus, set takefocus=1.
# text                  To display one or more lines of text in a 
#                       label widget, set this option to a string
#                       containing the text. Internal newlines 
#                       ('\n') will force a line break.
# textvariable          To slave the text displayed in a label 
#                       widget to a control variable of class
#                       StringVar, set this option to that variable
# underline             You can display an underline (_) below 
#                       the nth letter of the text, counting from
#                       0, by setting this option to n. The default
#                       is underline=-1, which means no underlining.
# width                 Width of the label in characters (not pixels!).
#                       If this option is not set, the label will be 
#                       sized to fit its contents.
# wraplength            You can limit the number of characters in 
#                       each line by setting this option to the 
#                       desired number. The default value, 0, 
#                       means that lines will be broken only at 
#                       newlines.


# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):     
       #Cambiamos el Cursor    
       lblMensaje.config(cursor="based_arrow_down")
       lblMensaje.config(width,50)
    
    if (estado==2):       
       #Cambiamos la altura
       lblMensaje.config(height=5)
   
    if (estado==3):       
       #Cambiamos el padx
       lblMensaje.config(padx=50)   
    
    if (estado==4):       
       #Cambiamos relieve
       #lblMensaje.config(bd=1)   
       lblMensaje.config(relief=GROOVE)   
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1
                 
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",                    
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)


# Crea el Objeto Label
lblMensaje = Label(vPrincipal,             # Objeto Padre
                   fg = "Blue",            # Color de Texto
                   text="una linea\nsegunda\ntercera",
                   #text="una linea",
                   width=50,
                   takefocus=1,
                   relief = RAISED ) 

#lblMensaje.pack()
lblMensaje.place(x = 20,y = 50)

# Ejecuta loop
vPrincipal.mainloop()