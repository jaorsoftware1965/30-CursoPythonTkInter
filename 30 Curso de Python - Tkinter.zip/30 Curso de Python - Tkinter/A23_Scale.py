# Curso de Python - Tkinter
# A23 Scale

# Importamos la librería
from tkinter import *

# Función para obtener el Valor
def fnObtenerValor():
   
   # Obtiene el valor
   seleccion = "Valor = " + str(var.get())
   
   # Lo coloca en la etiqueta
   etqMensaje.config(text = seleccion)

# Función para obtener el Valor
def fnObtenerValor2(valor):
   
   # Obtiene el valor
   seleccion = "Valor2 = " + str(valor)
   
   # Lo coloca en la etiqueta
   etqMensaje.config(text = seleccion)

# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A23 Scale")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Variable para controlar el Valor
var = DoubleVar()

# Crea el objeto Escala
scale = Scale( vPrincipal, 
               variable = var, 
               from_ = 1,
               to =10,
               orient = HORIZONTAL,
               command=fnObtenerValor2)
scale.pack()

# Crea un botón
btnObtener = Button(vPrincipal, 
                    text = "Obtener el Valor", 
                    command = fnObtenerValor)

# Agrega el Botón                    
btnObtener.pack()

# Crea la etiqueta
etqMensaje = Label(vPrincipal)

# Coloca la etiqueta
etqMensaje.pack()    
        
# Procesamiento de la ventana principal 
vPrincipal.mainloop()