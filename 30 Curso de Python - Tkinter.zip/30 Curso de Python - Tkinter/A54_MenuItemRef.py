# Curso de Python - Tkinter
# A54 MenuItem Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A54 MenuItem Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Menu item coption values
# accelerator           To display an “accelerator” keystroke 
#                       combination on the right side of a menu
#                       choice, use the option “accelerator=s” 
#                       where s is a string containing the
#                       characters to be displayed. For example, 
#                       to indicate that a command has Control-X 
#                       as its accelerator, use the option 
#                       “accelerator='^X'”. Note that this option
#                       does not actually implement the accelerator;
#                       use a keystroke binding to do that.
# activebackground      The background color used for choices when 
#                       they are under the mouse
# activeforeground      The foreground color used for choices when 
#                       they are under the mouse.
# background            The background color used for choices when
#                       they are not under the mouse. Note that 
#                       this cannot be abbreviated as bg.
# bitmap                Display a bitmap for this choice
# columnbreak           Normally all the choices are displayed 
#                       in one long column. If you set columnbreak=
#                       1, this choice will start a new column to 
#                       the right of the one containing the previous
#                       choice.
# columnbreak           Use option “columnbreak=True” to start a 
#                       new column of choices with this choice.
# command               A procedure to be called when this choice
#                       is activated
# compound              If you want to display both text and a 
#                       graphic (either a bitmap or an image) on 
#                       a menu choice, use this coption to specify 
#                       the location of the graphic relative to the
#                       text. Values may be any of tk.LEFT, tk.RIGHT,
#                       tk.TOP, tk.BOTTOM, tk.CENTER or tk.NONE. For
#                       example, a value of “compound=tk.TOP” would 
#                       position the graphic above the text.
# font                  The font used to render the label text.
# foreground            The foreground color used for choices when
#                       they are not under the mouse. Note that 
#                       this cannot be abbreviated as fg.
# hidemargin            By default, a small margin separates adjacent 
#                       choices in a menu. Use the coption “hidemargin=
#                       True” to suppress this margin. For example, 
#                       if your choices are color swatches on a 
#                       palette, this option will make the swatches 
#                       touch without any other intervening color
# image                 Display an image for this choice.
# label                 The text string to appear for this choice
# menu                  This option is used only for cascade 
#                       choices. Set it to a Menu object that 
#                       displays the next level of choices.
# offvalue              Normally, the control variable for a checkbutton
#                       is set to 0 when the checkbutton is off. 
#                       You can change the off value by setting 
#                       this option to the desired value
# onvalue               Normally, the control variable for a checkbutton 
#                       is set to 1 when the checkbutton is on. 
#                       You can change the on value by setting 
#                       this option to the desired value.
# selectcolor           Normally, the color displayed in a set 
#                       checkbutton or radiobutton is red. Change
#                       that color by setting this option to the 
#                       color you want.
# selectimage           If you are using the image option to 
#                       display a graphic instead of text on a 
#                       menu radiobutton or checkbutton, if you 
#                       use selectimage=I, image I will be displayed
#                       when the item is selected.
# state                 Normally, all choices react to mouse clicks,
#                       but you can set state=tk.DISABLED to gray 
#                       it out and make it unresponsive. This coption 
#                       will be tk.ACTIVE when the mouse is over the 
#                       choice.
# underline             Normally none of the letters in the label
#                       are underlined. Set this option to the
#                       index of a letter to underline that letter
# value                 Specifies the value of the associated control
#                       variable for a radiobutton. This can be an
#                       integer if the control variable is an IntVar,
#                       or a string if the control variable is a
#                       StringVar.
# variable              For checkbuttons or radiobuttons, this 
#                       option should be set to the control variable
#                       associated with the checkbutton or group of 
#                       radiobuttons



# Función que Procesa Menu
def fnProcesaMenu():   
   print ("Procesando Menu")

# Función que Sale
def fnSalir(event):   
   print("Salida 1")
   sys.exit(0)

# Función que Sale
def fnSalir2():   
   print("Salida 2")
   sys.exit(0)
      
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
        filemenu.entryconfigure(3,background="yellow")
            
    if (estado==2):
        filemenu.entryconfigure(3,foreground="green")       
   
    if (estado==3):       
        filemenu.entryconfigure(1,label="Salir")    
         
    if (estado==4):               
        filemenu.entryconfigure(1,accelerator="Control-X")
        
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

                       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 120,y = 120)

# Creamos la barra del Menu en vPrincipal
menubar = Menu(vPrincipal)

# Creamos un Menu para File
filemenu = Menu(menubar, tearoff = 0)

# Crea las opciones
filemenu.add_command(label = "Crear", command = fnProcesaMenu)
filemenu.add_command(label = "Abrir", command = fnSalir2)
filemenu.add_command(label = "Guardar", command = fnProcesaMenu)
filemenu.add_command(label = "Guardar como...", command = fnProcesaMenu)
filemenu.add_command(label = "Cerrar", command = fnProcesaMenu)

# Añade un Separador
filemenu.add_separator()

# Añade la opción Salidaa y la asocia a un comando
filemenu.add_command(label = "Salir",
                     accelerator="Ctrl+Q",
                     command = vPrincipal.quit)

# Asocia el Menu a la Barra
menubar.add_cascade(label = "Archivo", menu = filemenu)

# Crea el Menu de Edición
editmenu = Menu(menubar, tearoff=0)

# Añade las opciones
editmenu.add_command(label = "Deshacer", command = fnProcesaMenu)

# Añade un separador
editmenu.add_separator()

# Añade mas opciones
editmenu.add_command(label = "Cortar", command = fnProcesaMenu)
editmenu.add_command(label = "Copiar", command = fnProcesaMenu)
editmenu.add_command(label = "Pegar", command = fnProcesaMenu)
editmenu.add_command(label = "Borrar", command = fnProcesaMenu)
editmenu.add_command(label = "Seleccionar todo", command = fnProcesaMenu)

# Añade el Menu a la barra
menubar.add_cascade(label = "Edicion", menu = editmenu)

# Crea el Menu de Ayuda
helpmenu = Menu(menubar, tearoff=0)

# Agrega las opciones
helpmenu.add_command(label = "Help Index", command = fnProcesaMenu)
helpmenu.add_command(label = "About...", command = fnProcesaMenu)

# Agrega el Menu a la Barra
menubar.add_cascade(label = "Ayuda", menu = helpmenu)

# Genera el Bind
vPrincipal.bind_all("<Control-q>",fnSalir)
vPrincipal.bind_all("<Control-x>",fnSalir)

# Agrega a la ventana principal la Barra de Menu
vPrincipal.config(menu = menubar)        


# Ejecuta loop
vPrincipal.mainloop()