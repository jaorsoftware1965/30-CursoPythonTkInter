# Curso de Python - Tkinter
# A16 ListBox II

# En esta clase veremos algunos otras funciones del ListBox como lo son
# activar elementos, eliminar elementos, y visualizar elementos ocultos
# por su posicion en el despliegue.

# Importa la libreria
from tkinter import *

# Crea la Ventana Principal
vPrincipal = Tk()

# Coloca el Título
vPrincipal.title("A16 Listbox II")

# Se establece un tamaño
vPrincipal.geometry("400x150")

# Creamos un frame para la lista de Lenguajes
# No establecemos Width Height porque se ajustará al objeto que contiene
frmLenguajes = Frame (vPrincipal)         # Ventana Principal
                      
# Creamos un ScrollBar
scrollbar = Scrollbar(frmLenguajes)

# Colocamos el ScrollBar dentro del Frame 
scrollbar.pack(side=RIGHT, fill=Y)

# Creamos el listbox de Lenguajes
lstLenguajes = Listbox(frmLenguajes,                  # El Frame Contenedor
                       height=5,                      # La altura del listbox en lineas
                       width=25,                      # El Ancho del listbos en caracteres
                       selectmode = BROWSE,
                       yscrollcommand=scrollbar.set)  # Asociando el ScrollBar

# Lo colocamos dentro del frame
lstLenguajes.pack(side=LEFT,fill=BOTH)

# Asociamos el ScrollBar al listBox
scrollbar.config(command=lstLenguajes.yview)

# Agrega las opciones al Objeto
lstLenguajes.insert(1, "Python")
lstLenguajes.insert(2, "Perl")
lstLenguajes.insert(3, "C")
lstLenguajes.insert(4, "PHP")
lstLenguajes.insert(5, "JSP","Ruby","Pascal","Otro","otro","otro","mas")

# Agrega el objeto frame a la Ventana Principal
frmLenguajes.place(x=10,y=10)


# Creamos otro frame para la lista de Sistemas Operativos
frmSistemas = Frame (vPrincipal)         # Ventana Principal
                      

# Creamos un ScrollBar
scrollbar2 = Scrollbar(frmSistemas)

# Colocamos el ScrollBar dentro del Frame 
scrollbar2.pack(side=RIGHT, fill=Y)

# Creamos el listbox de Lenguajes
lstSistemas = Listbox(frmSistemas,                  # El Frame Contenedor
                       exportselection=0,          # Permanece la seleccion
                       height=5,                      # La altura del listbox en lineas
                       width=25,                      # El Ancho del listbos en caracteres
                       selectmode = EXTENDED,
                       yscrollcommand=scrollbar2.set)  # Asociando el ScrollBar

# Lo colocamos dentro del frame
lstSistemas.pack(side=LEFT,fill=BOTH)

# Asociamos el ScrollBar al listBox
scrollbar2.config(command=lstSistemas.yview)

# Agrega las opciones al Objeto
lstSistemas.insert(1, "Windows")
lstSistemas.insert(2, "Unix")
lstSistemas.insert(3, "Linux")
lstSistemas.insert(4, "Android")
lstSistemas.insert(5, "Macintosh","XWindows")

# Agrega el objeto frame a la Ventana Principal
frmSistemas.place(x=210,y=10)


# Se define funcion para controlar el click del botón Eliminar
def fnOnClickActivar():

    # Activa el Primer Elemento
    print("Activando el 2")
    #lstLenguajes.activate(2) No Funciona
  
    # Coloca el Foco en el Elemento
    lstLenguajes.select_set(2) #This only sets focus

    # Generale el Evento para que lo seleccione
    lstLenguajes.event_generate("<<ListboxSelect>>")
    
    
# Se define funcion para controlar el click del Button    
def fnOnClickEliminar():

    # Obtiene los item seleccionados
    itemSeleccionados = lstSistemas.curselection()
    
    # Obtiene el No. de Elementos 
    iElementosSeleccionados = len(itemSeleccionados)
    
    # Verifica que haya seleccionados
    while (iElementosSeleccionados > 0) :

        # Borra el Primer Item
        lstSistemas.delete(itemSeleccionados[0])           
        
        # Obtiene los item seleccionados
        itemSeleccionados = lstSistemas.curselection()
    
        # Obtiene el No. de Elementos 
        iElementosSeleccionados = len(itemSeleccionados)

# Se define funcion para controlar el click del boton Visible
def fnOnClickVisible():
    
    # Coloca el Foco en el Elemento
    lstLenguajes.see(7)

    # Coloca el Foco en el Elemento
    lstLenguajes.select_set(7) #This only sets focus on the first item.

    # Generale el Evento para que lo seleccione
    lstLenguajes.event_generate("<<ListboxSelect>>")


    
# Creamos el Boton Seleccionar
btnAceptar = Button(vPrincipal,                   # Ventana Padre
                    text = "Sel Lenguaje 2",         # Texto del Botón
                    command = fnOnClickActivar)   # Función controla Click

# Creamos el Boton Eliminar
btnCancelar = Button(vPrincipal,                   # Ventana Padre
                     text = "Eliminar Sistemas Sel",            # Texto del Botón
                     command = fnOnClickEliminar)  # Función controla Click

# Creamos el Boton Visible
btnVisible = Button(vPrincipal,                   # Ventana Padre
                     text = "Visible el Lenguaje 7",             # Texto del Boton
                     command = fnOnClickVisible)   # Funcion controla Click

# Ubica el Boton Aceptar 
btnAceptar.place(x = 10,y = 110)

# Ubica el Boton Cancelar
btnCancelar.place(x = 130,y = 110)

# Ubica el Boton Visible
btnVisible.place(x = 270,y = 110)

# Ciclo Principal
vPrincipal.mainloop()