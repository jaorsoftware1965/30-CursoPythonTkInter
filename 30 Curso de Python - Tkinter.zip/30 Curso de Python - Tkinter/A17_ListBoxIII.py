# Curso de Python - Tkinter
# A17 ListBox III

# En esta clase veremos otras funciones adicionales del ListBox como lo son
# detectar el Click, y hacer Scroll de los elementos por Elemento o por Página;
# y borrar todos los Elementos

# Importa la libreria
from tkinter import *

# Crea la Ventana Principal
vPrincipal = Tk()

# Coloca el Título
vPrincipal.title("A17 Listbox II")

# Se establece un tamaño
vPrincipal.geometry("400x150")

# Creamos un frame para la lista de Lenguajes
frmLenguajes = Frame (vPrincipal)         # Ventana Principal
                      
# Creamos un ScrollBar
scrollbar = Scrollbar(frmLenguajes)

# Colocamos el ScrollBar dentro del Frame 
scrollbar.pack(side=RIGHT, fill=Y)

# Creamos el listbox de Lenguajes
lstLenguajes = Listbox(frmLenguajes,                  # El Frame Contenedor
                       height=5,                      # La altura del listbox en lineas
                       width=25,                      # El Ancho del listbos en caracteres
                       selectmode = EXTENDED,
                       yscrollcommand=scrollbar.set)  # Asociando el ScrollBar

# Lo colocamos dentro del frame
lstLenguajes.pack(side=LEFT,fill=BOTH)

# Asociamos el ScrollBar al listBox
scrollbar.config(command=lstLenguajes.yview)

# Agrega las opciones al Objeto
lstLenguajes.insert(1, "Python")
lstLenguajes.insert(2, "Perl")
lstLenguajes.insert(3, "C")
lstLenguajes.insert(4, "PHP")
lstLenguajes.insert(5, "JSP","Ruby","Pascal","Otro","otro","otro","mas")

# Agrega el objeto frame a la Ventana Principal
frmLenguajes.place(x=10,y=10)

# Se define funcion para eliminar
def fnOnClickListBox(evento):
    print("Click:",evento,evento.type,evento.state)    
    print("Click en Listbox")
    print("Elementos Seleccionados",lstLenguajes.curselection())

# Enlaza el evento Select Listbox
lstLenguajes.bind("<<ListboxSelect>>", fnOnClickListBox)
    
# Se define funcion para eliminar
def fnOnClickEliminar():
    
    # Borra Todos los Elementos
    lstLenguajes.delete(0,END)           

# Se define funcion para Scroll
def fnScroll():
    
    # Borra Todos los Elementos
    lstLenguajes.yview_scroll(-1,UNITS)           
        
# Se define funcion para Scroll
def fnScrollPage():
    
    # Borra Todos los Elementos
    lstLenguajes.yview_scroll(-1,PAGES)           

    
# Creamos el Boton de Eleminar 
btnEliminar = Button(vPrincipal,                   # Ventana Padre
                    text = "Eliminar Todos",       # Texto del Botón
                    command = fnOnClickEliminar)   # Funcion controla Click

# Ubicar Todos
btnEliminar.place(x = 10,y = 110)

# Creamos el Boton de Scroll por Elemento
btnScroll = Button(vPrincipal,                    # Ventana Padre
                   text = "Scroll X Elemento",               # Texto del Botón
                   command = fnScroll)            # Funcion controla Click

# Ubicar Todos
btnScroll.place(x = 120,y = 110)

# Creamos el Boton de Scroll x Pagina 
btnScrollPage = Button(vPrincipal,                    # Ventana Padre
                       text = "Scroll X Pagina",      # Texto del Botón
                       command = fnScrollPage)            # Funcion controla Click

# Ubicar Todos
btnScrollPage.place(x = 250,y = 110)

# Ciclo Principal
vPrincipal.mainloop()