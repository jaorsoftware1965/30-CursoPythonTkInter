# Curso de Python - Tkinter
# A06 LabelImagen

# En esta clase veremos como crear un Label con una Imagen; a posicionarla en la Ventana
# y a controlar los Eventos Click, Enter y Leave del Mouse en la etiqueta.

# Se importa la librería
import tkinter


# Importa StringVar del Módulo
from tkinter import *

# Se importa la librería para messagebox
from tkinter import messagebox

# Creamos la Ventana
vPrincipal = tkinter.Tk()

# Establecemos un tamaño
vPrincipal.geometry("800x600+10+10")

# Colocamos el Título de la Ventana
vPrincipal.title("A06 LabelImagen")


# Carga la Imagen
img = PhotoImage(file='img/python-logo.png')

# Creo la Etiqueta
lblLogo = Label(vPrincipal, image=img,relief = RAISED)

# Coloco el Logo en la Ventana Principal
lblLogo.pack()
#lblLogo.pack(fill = X)                # Expande Horizontal
#lblLogo.pack(fill = X, expand = 1)    # Expande y Centra Verticalmente
#lblLogo.pack(fill = Y, expand = 1)    # Expande Vertical
#lblLogo.pack(fill = BOTH, expand = 1) # Expande a todo

# Define la función para ShowInfo
def fnLabelClick(evento):
    print("Click:",evento,evento.type,evento.state)
    #messagebox.showinfo("Click","Sobre la Imagen")

def fnLabelEnter(evento):
    print("Enter:",evento,evento.type,evento.focus,evento.state)
    
def fnLabelLeave(evento):
    print("Leave:",evento,evento.type,evento.focus,evento.state)
    

# Controla el Click
lblLogo.bind("<Button-1>", fnLabelClick)
lblLogo.bind("<Enter>" , fnLabelEnter)
lblLogo.bind("<Leave>" , fnLabelLeave)

# Despliegua la Ventana y ejecuta el loop principal que controla la aplicación
vPrincipal.mainloop()

