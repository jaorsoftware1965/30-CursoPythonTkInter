# Curso de Python - Tkinter
# A04 Control Teclado MessageBox

# En esta clase veremos como controlar el Teclado para Ejecución de Eventos
# y veremos como mostrar MessageBox's para interactuar con el Usuario.

# Se importa la librería
import tkinter

# Se importa la librería para messagebox
from tkinter import messagebox

# Creamos la Ventana
vPrincipal = tkinter.Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("A04 Control Teclado MessageBox")

# Define la Función de Cerrado
def fnCerrar():
    if messagebox.askokcancel("Salir", "¿ Desea Salir de la Aplicación ?"):
        vPrincipal.destroy()

# Define la función para ShowInfo
def fnShowInfo(evento):
    print("ShowInfo:",evento)
    messagebox.showinfo("Show Info","04 MessageBox")

def fnShowError(evento):
    print("ShowError:",evento)
    messagebox.showerror("Show Error","04 MessageBox")

def fnShowWarning(evento):
    print("ShowWarning:",evento)
    messagebox.showwarning("Show Warning","04 MessageBox")

def fnAskYesNo(evento):
    print("AskYesNo:",evento)
    messagebox.askyesno("Salir con Return", "¿ Desea Salir de la Aplicación ?")

def fnAskRetryCancel(evento):
    print("AskRetryCancel:",evento)
    messagebox.askretrycancel("Salir con Escape", "¿ Desea Salir de la Aplicación ?")        

# Define la Función para el Evento de Cerrar la Ventana
vPrincipal.protocol("WM_DELETE_WINDOW",fnCerrar)

# Controla el Evento del Teclado para Mostrar el MessageBo
vPrincipal.bind("<Control-Key-a>", fnShowInfo) #Funciona con Ctrl+1
vPrincipal.bind("<Control-Key-b>", fnShowError) #Funciona con Ctrl+2
vPrincipal.bind("<F1>", fnShowWarning) #Funciona con Ctrl+3
vPrincipal.bind("<Return>", fnAskYesNo) #Funciona con Ctrl+4
vPrincipal.bind("<Escape>", fnAskRetryCancel) #Funciona con Ctrl+5

# Despliegua la Ventana y ejecuta el loop principal que controla la aplicación
vPrincipal.mainloop()
