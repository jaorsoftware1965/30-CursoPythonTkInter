# Curso de Python - Tkinter
# A62 ScrollBar Reference II


# When the user manipulates a scrollbar, the scrollbar calls its command callback. The arguments to this
# call depend on what the user does:

# • When the user requests a movement of one “unit” left or up, for example by clicking button B1 on
# the left or top arrowhead, the arguments to the callback look like:
# command(tk.SCROLL, -1, tk.UNITS)

# • When the user requests a movement of one unit right or down, the arguments are:
# command(tk.SCROLL, 1, tk.UNITS)

# • When the user requests a movement of one page left or up:
# command(tk.SCROLL, -1, tk.PAGES)

# • When the user requests a movement of one page right or down:
# command(tk.SCROLL, 1, tk.PAGES)

# • When the user drags the slider to a value f in the range [0,1], where 0 means all the way left or up
# and 1 means all the way right or down, the call is:
# command(tk.MOVETO, f)

# These calling sequences match the arguments expected by the .xview() and .yview() methods of
# canvases, listboxes, and text widgets. The Entry widget does not have an .xview() method

# Importamos la librería

from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A62 ScrollBar Reference II")

# Se establece un tamaño
vPrincipal.geometry("400x100")
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
       scrollbar.config(command=(SCROLL, -1, UNITS))

    if (estado==2):
       scrollbar.config(command=(SCROLL,  1, UNITS))
                  
    if (estado==3):
       scrollbar.config(command=(SCROLL, -1, PAGES))
         
    if (estado==4):           
       scrollbar.config(command=(SCROLL,  1, PAGES))
       
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1
     
# Creamos el ScrollBar
scrollbar = Scrollbar(vPrincipal)

# Insertamos el Scrollbar a la Derecha con Llenado Vertical
scrollbar.pack( side = RIGHT, fill = Y )

     
# Creamos un LisBox
lstLenguajes = Listbox(vPrincipal,                      # Contenedor
	                   yscrollcommand = scrollbar.set ) # Indica el Scrollbar que controlara

# Agrega elementos al list box
lstLenguajes.insert(0,"C","C++","C#","Java","Python","Pascal","Ruby","php","asp","VB","ASM")

# Agrega el listbox a la ventana principal
lstLenguajes.pack( side = LEFT, fill = BOTH )

# Configura que el control del ScrollBar será por la función yview
scrollbar.config( command = lstLenguajes.yview )
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
        
# Ubicamos el Botón                            
btnCambiar.place(x = 150,y = 20)
                      
# Ejecuta loop
vPrincipal.mainloop()