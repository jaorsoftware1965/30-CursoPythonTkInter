# Curso de Python - Tkinter
# A50 LabelFrame Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A50 LabelFrame Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Creación
# LabelFrame(parent, option, ...)

# Propiedades
# bg or background      The labelframe's background color
# bd or borderwidth     Width of the labelframes's border. 
#                       The default is 2 pixels.
# cursor                The cursor used when the mouse is over 
#                       the labelframe widget
# fg or foreground      Color to be used for the widget
# height                The vertical dimension of the new frame.
#                       This will be ignored unless you also 
#                       call .grid_propagate(0) on the frame
# highlightbackground   Color of the focus highlight when the 
#                       labelframe does not have focus. 
# highlightcolor        Color shown in the focus highlight when 
#                       the labelframe has the focus.
# highlightthickness    Thickness of the focus highlight.
# labelanchor           Use this option to specify the position 
#                       of the label on the widget's border.
#                       The default position is 'nw', which 
#                       places the label at the left end of the
#                       top border.
# labelwidget           Instead of a text label, you can use any 
#                       widget as the label by passing that widget 
#                       as the value of this option. If you supply 
#                       both labelwidget and text options, the 
#                       text option is ignored
# padx                  Extra space added to the left and right 
#                       of the text within the widget. 
# pady                  Extra space added to above and top 
#                       of the text within the widget. 
# relief                Specifies the appearance of a decorative
#                       border around the label. The default is 
#                       tk.GROOVE
# takefocus             Normally, focus does not cycle through 
#                       Label widgets;if you want this widget to 
#                       be visited by the focus, set takefocus=1.
# text                  Text of the labelframe
# width                 The horizontal dimension of the new frame.
#                       This will be ignored unless you also 
#                       call .grid_propagate(0) on the frame.

# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):     
       #Cambiamos el Cursor    
       labelframe.config(cursor="based_arrow_down")
       labelframe.config(bd=5)
       #labelframe.config(text,"50")
    
    if (estado==2):       
       #Cambiamos el anchor
       labelframe.config(labelanchor="e")
   
    if (estado==3):       
       #Cambiamos el padx
       labelframe.config(padx=50)   
       labelframe.config(pady=50)   
    
    if (estado==4):       
       #Cambiamos relieve
       labelframe.config(relief=SUNKEN)   
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1


# Creamos el LabelFrame y lo asignamos a la ventana|
labelframe = LabelFrame(vPrincipal, 
                        text = "LabelFrame",
                        bg="blue", #Color de Fondo
                        bd=2, # Ancho del Borde
                        fg="white", #Color del texto 
                        padx=15, #Relleno izq-der
                        pady=15, #Rellono arr-aba
                        relief=RAISED,#GROOVE,FLAT,RIDGE,SUNKEN
                        labelanchor="n",
                        height=200,
                        width=50
                        )
                        
# Lo hacemos que llene a ambos lados y que se expanda
labelframe.pack(fill = "both", expand = "yes")
                        
# Creamos un botón
btnCambiar = Button(labelframe, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)

# Ejecuta loop
vPrincipal.mainloop()