# Curso de Python - Tkinter
# A51 Listbox Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A51 Listbox Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Creación
# Listbox(parent, option, ...)

# Propiedades
# activestyle           This option specifies the appearance of 
#                       the active line. It may have any of
#                       these values:
#                       'underline'
#                       The active line is underlined. 
#                       This is the default option.
#                       'dotbox'
#                       The active line is enclosed in a dotted 
#                       line on all four sides.
#                       'none'
#                       The active line is given no special 
#                       appearance.
# bg or background      The listbox's background color
# bd or borderwidth     Width of the Listbox's border. 
#                       The default is 2 pixels.
# cursor                The cursor used when the mouse is over 
#                       the listbox widget
# disabledforeground    The color of the text in the listbox when
#                       its state is tk.DISABLED.
# exportselection       By default, the user may select text with
#                       the mouse, and the selected text will be 
#                       exported to the clipboard. To disable this
#                       behavior, use exportselection=0.
# font                  The font used for the text in the listbox
# fg or foreground      Color to be used for the widget
# height                Number of lines. El default is 10
# highlightbackground   Color of the focus highlight when the 
#                       listbox does not have focus. 
# highlightcolor        Color shown in the focus highlight when 
#                       the listbox has the focus.
# highlightthickness    Thickness of the focus highlight.
# listvariable          A StringVar that is connected to the 
#                       complete list of values in the listbox.
#                       If you call the .get() method of the 
#                       listvariable, you will get back a string 
#                       of the form "('v0', 'v1', ...)", where 
#                       each vi is the contents of one line of 
#                       the listbox.
#                       To change the entire set of lines in the 
#                       listbox at once, call .set(s) on the
#                       listvariable, where s is a string containing
#                       the line values with spaces between them.
#                       For example, if listCon is a StringVar 
#                       associated with a listbox's listvariable 
#                       option, this call would set the listbox 
#                       to contain three lines:
#                       listCon.set('ant bee cicada')
#                       This call would return the string "('ant',
#                       'bee', 'cicada')":listCon.get()
# relief                Specifies the appearance of a decorative
#                       border around the label. The default is 
#                       tk.SUNKEN
# selectbackground      The background color to use displaying 
#                       selected text.
# selectborderwidth     The width of the border to use around selected
#                       text. The default is that the selected item
#                       is shown in a solid block of color selectbackground;
#                       if you selectborderwidth increase the 
#                       selectborderwidth, the entries are moved 
#                       farther apart and the selected entry shows
#                       tk.RAISED
# selectforeground      The foreground color to use displaying selected 
#                       text.
# selectmode            Determines how many items can be selected, 
#                       and how mouse drags affect the selection:
#                       • tk.BROWSE: Normally, you can only select 
#                       one line out of a listbox. If you click on
#                       an item and then drag to a different line,
#                       the selection will follow the mouse. This
#                       is the default.
#                       • tk.SINGLE: You can only select one line,
#                       and you can't drag the mouse—wherever you
#                       click button 1, that line is selected.
#                       • tk.MULTIPLE: You can select any number 
#                       of lines at once. Clicking on any line 
#                       toggles whether or not it is selected.
#                       • tk.EXTENDED: You can select any adjacent 
#                       group of lines at once by clicking on the
#                       first line and dragging to the last line.
# state                 By default, a listbox is in the tk.NORMAL
#                       state. To make the listbox unresponsive
#                       to mouse events, set this option to 
#                       tk.DISABLED.
# takefocus             Normally, the focus will tab through listbox 
#                       widgets. Set this option to 0 to take the 
#                       widget out of the sequence
# width                 The width of the widget in characters (not 
#                       pixels!). The width is based on an average
#                       character, so some strings of this length 
#                       in proportional fonts may not fit. The 
#                       default is 20.
# xscrollcommand        If you want to allow the user to scroll 
#                       the listbox horizontally, you can link
#                       your listbox widget to a horizontal scrollbar.
#                       Set this option to the .set method of the 
#                       scrollbar
# yscrollcommand        If you want to allow the user to scroll the 
#                       listbox vertically, you can link your 
#                       listbox widget to a vertical scrollbar. 
#                       Set this option to the .set method of the 
#                       scrollbar

#Métodos

#.activate(element=None)
# If no argument is provided, this method returns one of the 
# strings 'arrow1', 'arrow2', 'slider', or '', depending on where
# the mouse is. For example, the method returns 'slider' if the 
# mouse is on the slider. The empty string is returned if the 
# mouse is not currently on any of these three controls.
# To highlight one of the controls (using its activerelief relief 
# style and its activebackground color), call this method and pass 
# a string identifying the control you want to highlight, one of 
# 'arrow1', 'arrow2', or 'slider'.

# .delta(dx, dy)
# Given a mouse movement of (dx, dy) in pixels, this method returns 
# the float value that should be added to the current slider position
# to achieve that same movement. The value must be in the closed 
# interval [-1.0, 1.0].

# .fraction(x, y)
# Given a pixel location (x, y), this method returns the 
# corresponding normalized slider position in the interval 
# [0.0, 1.0] that is closest to that location. .get()
# Returns two numbers (a, b) describing the current position of 
# the slider. The a value gives the position of the left or top 
# edge of the slider, for horizontal and vertical scrollbars 
# respectively; the b value gives the position of the right or 
# bottom edge. Each value is in the interval [0.0, 1.0] where 0.0
# is the leftmost or top position and 1.0 is the rightmost or 
# bottom position. For example, if the slider
# extends from halfway to three-quarters of the way along the 
# trough, you might get back the tuple (0.5,0.75).

# .identify(x, y)
# This method returns a string indicating which (if any) of the 
# components of the scrollbar are under the given (x, y) coordinates.
# The return value is one of 'arrow1', 'trough1', 'slider', 
# 'trough2', 'arrow2', or the empty string '' if that location 
# is not on any of the scrollbar components.


# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):     
       #Cambiamos el Cursor    
       lstLenguajes.config(width=50)       
       lstLenguajes.config(cursor="based_arrow_down")
       lstLenguajes.config(state=NORMAL)   
              
    
    if (estado==2):       
       #Cambiamos que no tome el focus
       lstLenguajes.config(takefocus=0)
       lstLenguajes.config(height=5)
   
    if (estado==3):       
       #Cambiamos el padx
       lstLenguajes.config(selectmode=MULTIPLE)   
           
    if (estado==4):       
       #Cambiamos relieve
       lstLenguajes.config(state=DISABLED)   
       lstLenguajes.config(selectmode=SINGLE)   
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1


# Crea el Objeto ListBox;
lstLenguajes = Listbox(vPrincipal,                 # Contenedor
                       exportselection=0,          # Permanece la seleccion
                       highlightcolor="yellow",    # Color cuando se tiene el foco
					       selectbackground="red",     # Color de fondo de la Selección
	                    selectmode = SINGLE)        # Modo de Operación
	                  
# Agrega las opciones al Objeto
lstLenguajes.insert(1, "Python")
lstLenguajes.insert(2, "Perl")
lstLenguajes.insert(3, "C")
lstLenguajes.insert(4, "PHP")
lstLenguajes.insert(5, "JSP","Ruby","Pascal")

# Agrega el objeto a la Ventana Principal
lstLenguajes.place(x=10,y=10)
                        
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 220,y = 20)

# Ejecuta loop
vPrincipal.mainloop()