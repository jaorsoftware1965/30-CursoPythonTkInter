# Curso de Python - Tkinter
# A25 MenuButton

# Importamos la librería
from tkinter import *

# Función que Procesa Menu
def fnProcesaMenu():
    print (vpython.get())
    print (vjava.get())
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A25 MenuButton")

# Se establece un tamaño
vPrincipal.geometry("600x400")

#MenuButton
mb = Menubutton ( vPrincipal,
                  text = "Lenguajes", 
                  relief = RAISED )


# Crea un Menu y lo asocia al botón en la propieda menu
mb.menu  =  Menu ( mb, tearoff = 0 )
mb["menu"]  =  mb.menu

# Crea 2 variables    
vpython  = IntVar()
vjava    = IntVar()

# Crea un Grid para el botón
mb.grid()

# Agrega al Menu del Botón un chekbutton
mb.menu.add_checkbutton ( label = "python",
                          variable = vpython,
                          command = fnProcesaMenu)

# Agrega la Menu del Botón un checkbutton
mb.menu.add_checkbutton ( label = "java",
                          variable = vjava,
                          command = fnProcesaMenu)
# Prepara el Objeto
mb.pack()

# Procesamiento de la ventana principal 
vPrincipal.mainloop()