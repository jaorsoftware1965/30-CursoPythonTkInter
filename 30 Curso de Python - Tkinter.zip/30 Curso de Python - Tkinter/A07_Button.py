# Curso de Python - Tkinter
# A07 Button

# En esta clase veremos como crear un Button; configurar algunas de sus características
# controlar el evento click y el Hover y el leave; para mostrar un tooltip; obtener el
# texto del Botón y otras características mas.

# Se importa módulos librería
from tkinter import *

# Se crea la ventana principal
vPrincipal = Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("A07 Button")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Se define función para controlar el click del Button
def fnOnClickAceptar():

    # Las 2 instrucciones funcionan para cambiar el Texto del Label o Botón
    lblMensaje['text'] = 'Has Aceptado la Operación'
    btnAceptar.config(text='Ok')    
    
# Se define función para controlar el click del Button    
def fnOnClickCancelar():

    # Las 2 instrucciones funcionan para cambiar el Texto del Label o Botón
    lblMensaje['text'] = 'Has Cancelado la Operación'    
    # Ocultas el Botón
    btnCancelar.place_forget()    #lbl.grid_forget()   #lbl.pack_forget()
        
# Creamos el Botón Aceptar
btnAceptar = Button(vPrincipal,                   # Ventana Padre
                    text = "Aceptar",             # Texto del Botón
                    command = fnOnClickAceptar)   # Función controla Click

# Creamos el Botón Cancelar
btnCancelar = Button(vPrincipal,                   # Ventana Padre
                     text = "Cancelar",            # Texto del Botón
                     bg="green",                   # Color de Fondo
                     command = fnOnClickCancelar)  # Función controla Click

# Crea el Objeto Label
lblMensaje = Label(vPrincipal,         # Objeto Padre
                   # Texto del Botón
                   text = "Acerca el Apuntador del Mouse a los Botones para ver Ayudas",                   
                   relief = FLAT )    # Borde del Botón     

# Coloca el Mensaje
lblMensaje.place(x=10,y=10)

# Crea el Objeto Label
lblToolTip = Label(vPrincipal,                    # Objeto Padre
                   text="Ayuda del Sistema",             
                   relief = RAISED )                # Tipo de Borde SUNKEN, RAISED, GROOVE, RIDGE, and FLAT

# Coloca el Tooltip el cual no se ve porque no tiene texto
lblToolTip.place(x=0,y=100)
lblToolTip.place_forget()

# Ubica el Botón Aceptar 
btnAceptar.place(x = 50,y = 50)

# Ubica el Botón Cancelar
btnCancelar.place(x = 150,y = 50)

# Función Activar el Tooltip de Aceptar
def fnToolTipAceptarOn(evento):    
    
    # Obtengo el Texto del Botón
    sTexto = btnAceptar['text']

    # Verifica si el texto ya ha cambiado
    if (sTexto=="Ok"):
       # Modifica el Mensaje
       lblToolTip['text'] = 'Yas has aceptado la operación'
    else:
       # Modifica el Mensaje
       lblToolTip['text'] = 'Si presionas Aceptarás la Operación'

    # Colocas el Mensaje
    lblToolTip.place(x=50,y=80)

# Función Activar el Tooltip de Cancelar
def fnToolTipCancelarOn(evento):    
    
    # Modifica el Mensaje
    lblToolTip['text'] = 'Si presionas Cancelaras la Operación'

    # Activas el Mensaje
    lblToolTip.place(x=150,y=80)

# Evento para Ocultar el tooltip
def fnToolTipOff(evento):    

    # Ocultas el Mensaje
    lblToolTip.place_forget()    #lbl.grid_forget()   #lbl.pack_forget()


# Controla el ToolTip
btnAceptar.bind("<Enter>" , fnToolTipAceptarOn)
btnCancelar.bind("<Enter>" , fnToolTipCancelarOn)
btnAceptar.bind("<Leave>" , fnToolTipOff)
btnCancelar.bind("<Leave>" , fnToolTipOff)

# Ejecuta el Loop Principal
vPrincipal.mainloop()
