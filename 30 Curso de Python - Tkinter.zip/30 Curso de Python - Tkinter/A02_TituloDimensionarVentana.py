# Curso de Python - Tkinter
# A02 Titulo y Dimensionando la Ventana

# En esta clase veremos como Colocarle el Título a a Ventana y Dimensionarla

# Se importa la librería
import tkinter

# Creamos el Objeto de la Ventana Principal
vPrincipal = tkinter.Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("A02 Dimensionando la Ventana")

# Maximizar la Ventana
#vPrincipal.wm_state('zoomed')

# Actualiza los datos
#vPrincipal.update()

# Imprimiendo el Ancho y Alto del Screen y la Ventana
#print("Ancho Screen :",vPrincipal.winfo_screenwidth())
#print("Alto  Screen :",vPrincipal.winfo_screenheight())
#print("Ancho Ventana:",vPrincipal.winfo_width())
#print("Alto  Ventana:",vPrincipal.winfo_height())
#print("x            :",vPrincipal.winfo_x())
#print("y            :",vPrincipal.winfo_y())
#print(vPrincipal.geometry())

# Maximiza sin barra de Títulos
#vPrincipal.attributes('-fullscreen', True)

# Actualiza los datos
#vPrincipal.update()

# Imprimiendo el Ancho y Alto de la Ventana
#print("Ancho Screen :",vPrincipal.winfo_screenwidth())
#print("Alto  Screen :",vPrincipal.winfo_screenheight())
#print("Ancho Ventana:",vPrincipal.winfo_width())
#print("Alto  Ventana:",vPrincipal.winfo_height())
#print("x            :",vPrincipal.winfo_x())
#print("y            :",vPrincipal.winfo_y())
#print(vPrincipal.geometry())


# Obtiene el Ancho y e Alto
ancho = vPrincipal.winfo_screenwidth()
alto  = vPrincipal.winfo_screenheight()
print("Ancho:",ancho,"Alto:",alto)

# Aplica geometria
vPrincipal.geometry("%dx%d+%d+%d" %(ancho, alto, -8, -8))

# Actualizo
vPrincipal.update()

# Despliego los datos
print("Ancho Screen :",vPrincipal.winfo_screenwidth())
print("Alto  Screen :",vPrincipal.winfo_screenheight())
print("Ancho Ventana:",vPrincipal.winfo_width())
print("Alto  Ventana:",vPrincipal.winfo_height())
print("x            :",vPrincipal.winfo_x())
print("y            :",vPrincipal.winfo_y())
print(vPrincipal.geometry())

# Minimizar Iconizar la Ventana
#vPrincipal.wm_state('iconic')
#vPrincipal.iconify()

# Normalizar la Ventana
#vPrincipal.wm_state('normal')

# Despliegua la Ventana y ejecuta el loop principal que controla la aplicación
vPrincipal.mainloop()
