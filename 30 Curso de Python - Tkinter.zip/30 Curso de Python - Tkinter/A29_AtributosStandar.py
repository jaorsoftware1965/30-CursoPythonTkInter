# Curso de Python - Tkinter
# A29 Atributos Standar

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A29_AtributosStandar")

# Se establece un tamaño
vPrincipal.geometry("600x400")    

#Definimos una funcion para Mensaje
def fnCambiarDimension():
    btnCambiar.config(text="Cambiado",
                      width=50,
                      bg="blue")
                      

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar", 
                    command = fnCambiarDimension)

# Ubicamos el Botón                            
btnCambiar.place(x = 35,y = 50)

# Ejecuta loop
vPrincipal.mainloop()