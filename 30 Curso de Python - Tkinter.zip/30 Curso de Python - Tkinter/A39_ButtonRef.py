# Curso de Python - Tkinter
# A39 Button Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A39 Button Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Propiedades de Button
# activebackground    Background color when the button is 
#                     under the cursor.
# activeforeground    Foreground color when the button is 
#                     under the cursor.
# anchor              Where the text is positioned on the 
#                     button.
# bd or borderwidth   Width of the border around the 
#                     outside of the button. Default 2
#                     pixels
# bg or background    Normal background color
# bitmap              Name of one of the standard 
#                     bitmaps to display on the button 
#                     (instead of text).
# command             Function or method to be called 
#                     when the button is clicked.
# cursor              Selects the cursor to be shown when 
#                     the mouse is over the button.
# default             tk.NORMAL is the default; use 
#                     tk.DISABLED if the button is to be
#                     initially disabled (grayed out, 
#                     unresponsive to mouse clicks).
# disabledforeground  Foreground color used when the button 
#                     is disabled.
# fg or foreground    Normal foreground (text) color.
# font                Text font to be used for the button's 
#                     label.
# height              Height of the button in text lines (for 
#                     textual buttons) or pixels (for images).      
# highlightbackground Color of the focus highlight when the 
#                     widget does not have focus.
# highlightcolor      The color of the focus highlight when 
#                     the widget has focus.
# highlightthickness  Thickness of the focus highlight.
# image               Image to be displayed on the button 
#                     (instead of text).
# justify             How to show multiple text lines: tk.LEFT
#                     to left-justify each line; tk.CENTER to 
#                     center them; or tk.RIGHT to right-justify
# overrelief          The relief style to be used while the 
#                     mouse is on the button; default relief
#                     is tk.RAISED.
# padx                Additional padding left and right of the
#                     text. 
# pady                Additional padding above and below the 
#                     text
# relief              Specifies the relief type for the button 
#                     The default relief is tk.RAISED.
# repeatdelay         See repeatinterval, below.
# repeatinterval      Normally, a button fires only once when 
#                     the user releases the mouse button.
#                     If you want the button to fire at 
#                     regular intervals as long as the mouse 
#                     button is held down, set this option 
#                     to a number of milliseconds to be used 
#                     between repeats, and set the repeatdelay 
#                     to the number of milliseconds to wait
#                     before starting to repeat. For example,
#                     if you specify “repeatdelay=500,
#                     repeatinterval=100” the button will fire
#                     after half a second, and every tenth of
#                     a second thereafter, until the user 
#                     releases the mouse button. If the user
#                     does not hold the mouse button down at 
#                     least repeatdelay milliseconds,the 
#                     button will fire normally
# state               Set this option to tk.DISABLED to gray 
#                     out the button and make it unresponsive.
#                     Has the value tk.ACTIVE when the mouse
#                     is over it. Default is tk.NORMAL.
# takefocus           Normally, keyboard focus does visit 
#                     buttons, and a space character acts as
#                     the same as a mouse takefocus click,
#                     “pushing” the button. You can set the 
#                     takefocus option to zero to prevent 
#                     focus from visiting the button.

# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):       
       btnCambiar.config(activebackground="blue")       
       btnCambiar.config(activeforeground="red")  
       btnCambiar.config(bg="yellow")       
       btnCambiar.config(fg="blue")       
    
    if (estado==2):       
       btnCambiar.config(height=5)       
       btnCambiar.config(pady=10)     
    
    if (estado==3):       
       btnCambiar.config(padx=50)            
       btnCambiar.config(overrelief=FLAT)       
    
    if (estado==4):       
       btnCambiar.config(activebackground=colorabg)            
       btnCambiar.config(activeforeground=colorafg)            
       btnCambiar.config(bg=colorbg)            
       btnCambiar.config(fg=colorfg)            
       btnCambiar.config(height=vHeight)            
       btnCambiar.config(pady=vPady)            
       btnCambiar.config(padx=vPadx)            
       btnCambiar.config(overrelief=vOverRelief)           
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1
       
    
    
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)

                 
# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)

# guardo configuracion inicial
colorabg    = btnCambiar.cget("activebackground")
colorafg    = btnCambiar.cget("activeforeground")
colorbg     = btnCambiar.cget("bg")
colorfg     = btnCambiar.cget("fg")
vHeight     = btnCambiar.cget("height")
vPady       = btnCambiar.cget("pady")
vPadx       = btnCambiar.cget("padx")
vOverRelief = btnCambiar.cget("overrelief")


print (colorabg)
print (colorafg)
print (colorfg)
print (colorbg)
print (vHeight)
print (vPady)
print (vPadx)
print (vOverRelief)


# Ejecuta loop
vPrincipal.mainloop()