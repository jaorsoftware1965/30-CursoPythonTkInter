# Curso de Python - Tkinter
# A42 Canvas Bitmap

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A42 Canvas Bitmap")

# Se establece un tamaño
vPrincipal.geometry("450x450")

# Métodos
# create_bitmap()

# Crea el objeto canvas
xCanvas = Canvas(vPrincipal,   # Ventana Padre
	              bg = "blue",  # Color de Fondo
	              height = 400, # Alto
	              width =400)   # Ancho

# Crea un bitmap con 2 colores 0 blanco y 1 negro
# create_bitmap(x, y,options ...)

# Atributos
# activebackground,   These options specify the background, bitmap
# activebitmap,       and foreground values when the bitmap is
# activeforeground    active, that is, when the mouse is over the 
#                     bitmap

# anchor              The bitmap is positioned relative to point 
#                     (x, y). The default is anchor=tk.CENTER, 
#                     meaning that the bitmap is centered on the 
#                     (x, y) position.
#                     For example, if you specify anchor=tk.NE, 
#                     the bitmap will be positioned so that point
#                     (x, y) is located at the northeast (top right)
#                     corner of the bitmap
# background          The color that will appear where there are 0 
#                     values in the bitmap. The default is 
#                     background='', meaning transparent
# bitmap              The bitmap to be displayed
# disabledbackground, These options specify the background, bitmap
# disabledbitmap,     and foreground to be used when the bitmap'                     s
# disabledforeground  state is tk.DISABLED
# foreground          The color that will appear where there are
#                     1 values in the bitmap. The default is 
#                     foreground='black'.
# state               By default, items are created with 
#                     state=tk.NORMAL. Use tk.DISABLED to make 
#                     the item grayed out and unresponsive to 
#                     events; use tk.HIDDEN to make the item 
#                     invisible
# tags                If a single string, the bitmap is tagged 
#                     with that string. Use a tuple of strings
#                     to tag the bitmap with multiple tags

# Variable Global
estado = 1

BITMAP = """
#define im_width 32
#define im_height 32
static char im_bits[] = {
0xaf,0x6d,0xeb,0xd6,0x55,0xdb,0xb6,0x2f,
0xaf,0xaa,0x6a,0x6d,0x55,0x7b,0xd7,0x1b,
0xad,0xd6,0xb5,0xae,0xad,0x55,0x6f,0x05,
0xad,0xba,0xab,0xd6,0xaa,0xd5,0x5f,0x93,
0xad,0x76,0x7d,0x67,0x5a,0xd5,0xd7,0xa3,
0xad,0xbd,0xfe,0xea,0x5a,0xab,0x69,0xb3,
0xad,0x55,0xde,0xd8,0x2e,0x2b,0xb5,0x6a,
0x69,0x4b,0x3f,0xb4,0x9e,0x92,0xb5,0xed,
0xd5,0xca,0x9c,0xb4,0x5a,0xa1,0x2a,0x6d,
0xad,0x6c,0x5f,0xda,0x2c,0x91,0xbb,0xf6,
0xad,0xaa,0x96,0xaa,0x5a,0xca,0x9d,0xfe,
0x2c,0xa5,0x2a,0xd3,0x9a,0x8a,0x4f,0xfd,
0x2c,0x25,0x4a,0x6b,0x4d,0x45,0x9f,0xba,
0x1a,0xaa,0x7a,0xb5,0xaa,0x44,0x6b,0x5b,
0x1a,0x55,0xfd,0x5e,0x4e,0xa2,0x6b,0x59,
0x9a,0xa4,0xde,0x4a,0x4a,0xd2,0xf5,0xaa
};
"""
# Carga una imagen con BitMapImage
imgBM = BitmapImage(data=BITMAP,background="blue", foreground="red")
                    

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):       
       # Creamos un ovalo
       xCanvas.create_bitmap(100,100, 
                             bitmap = "warning")
    
    if (estado==2):       
       # Creamos un ovalo
       xCanvas.create_bitmap(100,100, 
                             bitmap = "error")
    
    if (estado==3):       
       # Creamos un ovalo
       xCanvas.create_bitmap(100,100, 
                             bitmap = "questhead")
            
    # Incremento estado
    estado = estado + 1
    
    if (estado == 4):
       estado = 1

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    image = imgBM,
                    command = fnCambiarEstado)
                    
# Ubicamos el Botón                            
btnCambiar.place(x = 205,y = 410)
                 
# Agregamos el objeto a la Ventana
xCanvas.pack()

# Ejecuta loop
vPrincipal.mainloop()