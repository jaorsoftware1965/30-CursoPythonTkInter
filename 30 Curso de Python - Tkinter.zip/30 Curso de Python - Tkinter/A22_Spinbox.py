# Curso de Python - Tkinter
# A22 Spinbox

# Importamos la librería
from tkinter import *

# Para obtener el radio seleccionado
def fnValor():        
    # Obtiene la Seleccion
    seleccion = "El valor: " + str(sbCalificacion.get())
    
    # Coloca el texto en la etiqueta
    etqMensaje.config(text = seleccion)

# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A21 RadioButton")

# Se establece un tamaño
vPrincipal.geometry("400x200")

var = IntVar()

# Crea el Spinbox
sbCalificacion = Spinbox(vPrincipal, 
                         from_ = 0, 
                         to = 10,        
                         increment = 2,
                         text = "12",
                         values =(1,3,5,7,9,11,33,45),
                         command=fnValor,
                         keys = fnValor)
# Ubica el objeto                         
sbCalificacion.pack()

# Crea la etiqueta
etqMensaje = Label(vPrincipal)

# Coloca la etiqueta
etqMensaje.pack()    

        
# Procesamiento de la ventana principal 
vPrincipal.mainloop()