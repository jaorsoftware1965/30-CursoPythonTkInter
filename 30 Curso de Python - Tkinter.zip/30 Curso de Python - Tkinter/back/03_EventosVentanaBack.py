# Curso de Python - Tkinter

# Se importa la librería; Nota. en Python 2 era Tkinter; ahora; en Python 3 es tkinter
import tkinter

from tkinter import messagebox

# Llamamos con la librería al método Tk() que lo que hace es construir una ventana principal
# y asignamos esta funcón a una variable; la cual será el que el controle el objeto
vPrincipal = tkinter.Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("02_TitleMaximize")

#Maximizar la Ventana
#vPrincipal.wm_state('zoomed')
#vPrincipal.update()

# Define la Función de Cerrado
def on_closing():
    if messagebox.askokcancel("Salir", "¿ Deseas Salir de la Aplicación ?"):
        vPrincipal.destroy()

def resize(event):
    print(event.type)
    print(event)
    messagebox.showinfo("Has dimensionado","mENSAJE")


# Define la Función para el Evento de Cerrar la Ventana
vPrincipal.protocol("WM_DELETE_WINDOW", on_closing)
#vPrincipal.protocol("WM_ICONIFY", on_closing)
#vPrincipa l.protocol("wm_iconify", on_closing)

vPrincipal.bind("<Configure>", resize)
#vPrincipal.bind("<Enter>", resize) Funciona Hover sobre la ventana
#vPrincipal.bind("<Control-Key-1>", resize) Funciona con Ctrl+1


# Despliegua la Ventana y ejecuta el loop principal que controla la aplicación
vPrincipal.mainloop()
