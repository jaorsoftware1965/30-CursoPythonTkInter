# Curso de Python - Tkinter
# A44 Canvas Window

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A44 Canvas Window")

# Se establece un tamaño
vPrincipal.geometry("450x450")

# Métodos
# create_window()

# Crea el objeto canvas
xCanvas = Canvas(vPrincipal,   # Ventana Padre
	              height = 400, # Alto
                 bg="blue",     
	              width =400)   # Ancho

# Crea windows en el canvas
# create_window(x, y,options ...)

# Atributos
# anchor          The default is anchor=tk.CENTER, meaning that 
#                 the window is centered on the (x, y) position.
#                 For example, if you specify anchor=tk.E, the 
#                 window will be positioned so that point (x, y)
#                 is on the midpoint of its right-hand (east) edge.
# height          The height of the area reserved for the window. 
#                 If omitted, the window will be sized to fit the
#                 height of the contained widget.
# state           By default, window items are in the tk.NORMAL 
#                 state. Set this option to tk.DISABLED to make
#                 the window unresponsive to mouse input, or to 
#                 tk.HIDDEN to make it invisible.
# tags            If a single string, the window is tagged with 
#                 that string. Use a tuple of strings to tag the
#                 window with multiple tags
# width           The width of the area reserved for the window.
#                 If omitted, the window will be sized to fit the
#                 width of the contained widget.
# window          Use window=w where w is the widget you want to
#                 place onto the canvas. If this is omitted 
#                 initially, you can later call C.itemconfigure 
#                 (id, window=w) to place the widget w onto
#                 the canvas, where id is the window's object ID..


# Variable Global
estado = 1

                   
# Cambiar el Estado
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):       
       # Creamos una Ventana
       xCanvas.create_window(10,10,
                             window=btnCambiar)
                     
    
    if (estado==2):       
       # Creamos una Ventana
       xCanvas.create_window(100,100,
                             window=btnCambiar,
                             width=150,
                             height=150)
                             
    if (estado==3):       
       # Creamos una Ventana
       xCanvas.create_window(100,100,
                             window=btnCambiar,
                             width=150,
                             anchor=S,
                             height=150)                         
    if (estado==4):       
       # Creamos una Ventana
       xCanvas.create_window(100,100,
                             window=btnCambiar,
                             width=150,
                             anchor=N,
                             height=150)                         
                             
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                    
# Ubicamos el Botón                            
btnCambiar.place(x = 205,y = 410)
                 
# Agregamos el objeto a la Ventana
xCanvas.pack()

# Ejecuta loop
vPrincipal.mainloop()