# Curso de Python - Tkinter
# A47 Entry Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A47 Entry Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Funciones del Método Entry
# .delete(first, last=None) visto
# Deletes characters from the widget, starting with the one at
# index first, up to but not including the character at position
# last. If the second argument is omitted, only the single 
# character at position first is deleted.

# .get()
# Returns the entry's current text as a string.

# .icursor(index) visto
# Set the insertion cursor just before the character at the 
# given index.

# .index(index)
# Shift the contents of the entry so that the character at 
# the given index is the leftmost visible character.
# Has no effect if the text fits entirely within the entry.

# .insert(index, s)
# Inserts string s before the character at the given index.

# .scan_dragto(x)
# See the scan_mark method below.

# .scan_mark(x)
# Use this option to set up fast scanning of the contents of the
# Entry widget that has a scrollbar that supports horizontal 
# scrolling.
# To implement this feature, bind the mouse's button-down event
# to a handler that calls scan_mark(x), where x is the current
# mouse x position. Then bind the <Motion> event to a handler
# that calls scan_dragto(x), where x is the current mouse x 
# position. The scan_dragto method scrolls the contents of the 
# Entry widget continuously at a rate proportional to the 
# horizontal distance between the position at the time of the 
# scan_mark call and the current position.

# .select_adjust(index) visto
# This method is used to make sure that the selection includes 
# the character at the specified index.
# If the selection already includes that character, nothing 
# happens. If not, the selection is expanded from its current 
# position (if any) to include position index.

# .select_clear() visto
# Clears the selection. If there isn't currently a selection,
# has no effect.

# .select_from(index)
# Sets the tk.ANCHOR index position to the character selected by
# index, and selects that character.

# .select_present()visto
# If there is a selection, returns true, else returns false.

# .select_range(start, end) visto
# Sets the selection under program control. Selects the text 
# starting at the start index, up to but not including the 
# character at the end index. The start position must be before
# the end position. To select all the text in an entry widget 
# e, use e.select_range(0, tk.END).

# .select_to(index)
# Selects all the text from the tk.ANCHOR position up to but not
# including the character at the given index.

# .xview(index)
# Same as .xview(). This method is useful in linking the Entry 
# widget to a horizontal scrollbar.

# .xview_moveto(f)
# Positions the text in the entry so that the character at 
# position f, relative to the entire text, is positioned at the
# left edge of the window. The f argument must be in the range
# [0,1], where 0 means the left end of the text and 1 the right
# end.

# .xview_scroll(number, what)
# Used to scroll the entry horizontally. The what argument must
# be either tk.UNITS, to scroll by character widths, or tk.PAGES,
# to scroll by chunks the size of the entry widget. The number is
# positive to scroll left to right, negative to scroll right to 
# left. For example, for an entry widget e, e.xview_scroll(-1, 
# tk.PAGES) would move the text one “page” to the right, and
# e.xview_scroll(4, tk.UNITS) would move the text four characters
# to the left.


# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):     
       #Inserta texto    
       txtPrueba.insert(0,"Texto Insertado")
       txtPrueba.select_from(5)
    
    if (estado==2):       
       #Inserta texto    
       txtPrueba.insert(2,"222")
    
    if (estado==3): 
       #Obtiene el texto
       print(txtPrueba.get())
           
    if (estado==4):       
       # Selecciona todo
       txtPrueba.select_to(5)
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1
       
    
    
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)

# Crea un Texto de Entrada
txtPrueba = Entry(vPrincipal)

# Ubica el Control en la Pantalla
txtPrueba.place(x = 120,y = 20)



# Ejecuta loop
vPrincipal.mainloop()