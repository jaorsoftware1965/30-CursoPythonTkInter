# Curso de Python - Tkinter
# A09 Entry

# En esta clase veremos como crear un objeto Entry, como controlar la captura
# de cada uno de sus caracteres; como obtener el texto capturado; como justificarlo
# a la derecha, como indicar que aparezcan *'s para una entrada de password; y como
# insertar caracteres en la entrada de Texto.

# Opciones de Desarrollo de un Aplicación

# ----------------------------------------
# Agenda de Consultorio Médico
# Control de Comandas de Restaurante
# Punto de Venta
# Sugerida por los Usuario
# ----------------------------------------

# Se desarrollará la que mas votos tenga

# Se importa la Librería
from tkinter import *

# La Ventana Principal
vPrincipal = Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("A09 Entry")

# Se establece un tamaño
vPrincipal.geometry("280x120")

# Creamos un Label para Usuario
lblUsuario = Label(vPrincipal, text = "Usuario:")
lblUsuario.place(x = 20,y = 20)

# Función KeyPress Clave
def fnKeyPressUsuario(key):    
    print(key.keycode)
    print(key.char)
    if (key.keycode==27):
        vPrincipal.destroy()
    elif (key.keycode==13):
        print(txtUsuario.get())

# Crea un Texto de Entrada para Usuario
txtUsuario = Entry(vPrincipal,     # Parent
                   bd = 5,         # Tamaño del Borde
                   justify =RIGHT) # Alineación 

# Ubica el Control en la Pantalla
txtUsuario.place(x = 120,y = 20)

# Creamos un Label para Clave
lblClave = Label(vPrincipal, text = "Clave:")
lblClave.place(x = 20,y = 50)


# Función KeyPress Clave
def fnKeyPressClave(key):    
    print(key.keycode)
    print(key.char)
    if (key.keycode==27):
        vPrincipal.destroy()
    elif (key.keycode==13):
        txtClave.insert(0,"insertado")
        print(txtClave.get())    

# Crea un Texto de Entrada para Clave
txtClave = Entry(vPrincipal, 
                 bd = 2,    
                 show="*")

txtClave.place(x = 120,y = 50)


               
# Crea el Botón de Aceptar
btnAceptar = Button(vPrincipal,                   # Ventana Padre
                    text = "Aceptar",             # Texto del Botón
                    activebackground="white",     # Color de Fondo al presionar el botón
                    width = 10,                   # Ancho del Botón
                    activeforeground="green")    

# Ubica el Botón de Aceptar
btnAceptar.place(x=20, y = 80)

# Captura el Evento Key para las Entradas
txtClave.bind("<Key>", fnKeyPressClave)
txtUsuario.bind("<Key>", fnKeyPressUsuario)

# El Loop Principal
vPrincipal.mainloop()

print("Fin")