# Curso de Python - Tkinter
# A28 MessageBoxII

# Importamos la librería
from tkinter import *
from tkinter import messagebox
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A28 MessageBoxII")

# Se establece un tamaño
vPrincipal.geometry("600x400")    

#Definimos una funcion para Mensaje
def fnMensaje():
    # Desplegamos el MessageBox
    x=messagebox.askokcancel("Ok Cancel", 
                             "Mensaje")
    print (x)                       
    x=messagebox.askquestion("Ask Question", 
                             "Mensaje")                           
    print (x)             
    
    x=messagebox.askretrycancel("Ask Retry Cancel", 
                                "Mensaje")                           
    print (x)                              
                           
    x=messagebox.askyesno("Ask Yes No", 
                        "Mensaje")                    
    print (x)                    
                       
    messagebox.showerror("Show Error", 
                         "Mensaje")                       

    messagebox.showwarning("Show Warning", 
                           "Mensaje")                         

# Creamos un botón
btnDesplegarMsgBox = Button(vPrincipal, 
                            text = "Desplegar Varios MsgBox", 
                            command = fnMensaje)

# Ubicamos el Botón                            
btnDesplegarMsgBox.place(x = 35,y = 50)

# Ejecuta loop
vPrincipal.mainloop()