# Curso de Python - Tkinter
# A38 Atributo Geometry

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A38 Atributo Geometry")

# Se establece un tamaño
vPrincipal.geometry("400x200")


# Geometria
# El atributo geometria se utiliza para definir
# la posición y el tamaño de una ventana
# Este dato tiene el siguiente formato
# "wxhxy"
# w = ancho
# h = alto
# x = posicion en el eje x; si es positivo es izq a
#     derecha; si es negativo; es de derecha a izq
# y = posicion en el eje x; si es positivo es arriba
#     hacia abajo; si es negativo; es de abajo hacia
#     arriba

# Variable Global
geometria = 1

# Cambiar la Geometria
def fnCambiarGeometria():
    # Indico que variable es global
    global geometria
            
    if (geometria==1):       
       print("Geometria 600x600+10+10")
       vPrincipal.geometry("600x600+10+10")       
    
    if (geometria==2):       
       print("Geometria 600x600-10-10")
       vPrincipal.geometry("600x600-10-10")       
       
    if (geometria==3):       
       print("Geometria 300x300+100-100")
       vPrincipal.geometry("300x300+100-100")          
    
    if (geometria==4):       
       print("Geometria 300x300-100+100")
       vPrincipal.geometry("300x300-100+100")              
        
    # Incremento la posicion       
    geometria = geometria + 1
    
    if (geometria == 5):
       geometria = 1
       
    
    
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarGeometria)
                    
# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)


# Ejecuta loop
vPrincipal.mainloop()