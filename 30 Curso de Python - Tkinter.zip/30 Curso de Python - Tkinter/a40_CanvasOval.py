# Curso de Python - Tkinter
# A40 Canvas Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A40 Canvas Oval")

# Se establece un tamaño
vPrincipal.geometry("450x450")

# Métodos
# create_arc()       Visto
# create_image()     Visto
# create_line()      Visto
# create_rectangle() Visto
# create_oval()
# create_polygon()
# create_bitmap()   
# create_text()
# create_window()

# Crea el objeto canvas
xCanvas = Canvas(vPrincipal,   # Ventana Padre
	              bg = "blue",  # Color de Fondo
	              height = 400, # Alto
	              width =400)   # Ancho

# Crea un ovalo
# create_oval(x0, y0, x1, y1, option, ...)

# Atributos
# activedash, activefill, activeoutline, outactiveoutlinestipple
# activestipple, activewidth

# These options specify the dash pattern, fill color, outline 
# color, outline stipple pattern, interior stipple pattern, and 
# outline width values to be used when the oval is in the 
# tk.ACTIVE state, that is, when the mouse is over the oval. 
# For option values, see dash, fill, outline, outactiveoutlinestipple
# linestipple, stipple, and width.

# dash             To produce a dashed border around the oval, 
#                  set this option to a dash pattern
# dashoffset       When using the dash option, the dashoffset 
#                  option is used to change the alignment of the
#                  border's dash pattern relative to the oval.

# disableddash, disabledfill, disabledoutline, disabledoutlinestipple
# disabledstipple, disabledwidth

# These options specify the appearance of the oval when the item's 
# state is tk.DISABLED

# fill             The default appearance of an oval's interior 
#                  is transparent, and a value of fill='' will 
#                  select this behavior. You can also set this 
#                  option to fill any color and the interior of 
#                  the ellipse will be filled with that color
# offset           Stipple pattern offset of the interior. 
# outline          The color of the border around the outside of
#                  the ellipse. Default is outline='black'
# outlineoffset    Stipple pattern offset of the border. 
# stipple          A bitmap indicating how the interior of the 
#                  ellipse will be stippled. Default is 
#                  stipple='', which means a solid color. 
#                  A typical value would be stipple='gray25'.
#                  Has no effect unless the fill has been set to
#                  some color. 
# outlinestipple   Stipple pattern to be used for the border. 
#                  For option values, see stipple below
# state            By default, oval items are created in state 
#                  tk.NORMAL. Set this option to tk.DISABLED to
#                  make the oval unresponsive to mouse actions. 
#                  Set it to tk.HIDDEN to make the item invisible
# tags             If a single string, the oval is tagged with 
#                  that string. Use a tuple of strings to tag the
#                  oval with multiple tags.
# width            Width of the border around the outside of the
#                  ellipse. Default is 1 pixel; If you set this
#                  to zero, the border will not appear. If you 
#                  set this to zero and make the fill transparent,
#                  you can make the entire oval disappear

# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):       
       # Creamos un ovalo
       oval = xCanvas.create_oval(10,10,150,150,  # coordenadas
                                 dash=(3,5),
	                              fill = "red")    # color del arco
    
    if (estado==2):       
       # Creamos un ovalo
       oval = xCanvas.create_oval(10,10,50,50,    # coordenadas
                                 dash=(13,25),
	                              fill = "yellow") # color del arco
        
    if (estado==3):       
       # Creamos un ovalo
       oval = xCanvas.create_oval(110,110,170,170,    # coordenadas
                                 dash=(10,20),
	                              fill = "green") # color del arco
            
    # Incremento estado
    estado = estado + 1
    
    if (estado == 4):
       estado = 1

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                    
# Ubicamos el Botón                            
btnCambiar.place(x = 205,y = 410)
                 
# Agregamos el objeto a la Ventana
xCanvas.pack()

# Ejecuta loop
vPrincipal.mainloop()