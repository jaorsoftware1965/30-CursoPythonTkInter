# Curso de Python - Tkinter
# A58 PanedWindowII Reference

# Cada elemento hijo que sea insertado a un PanedWindow con el
# método add, tiene su propio conjunto de opciones de configuración
# las cuales veremos en esta referencia

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A58 PanedWindowII Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Propiedades para option
# after                 Normally, when you .add() a new child to
#                       a PanedWindow, the new child is added after
#                       any existing child widgets. You may instead
#                       use the after=w option to insert the new
#                       widget at a position just after an existing 
#                       child widget w.

# before                When used as option before=w in a call to
#                       the .add() method, places the new widget at
#                       a position just before an existing child 
#                       widget w.

# height                This option specifies the desired height of 
#                       the child widget.

# minsize               Use this option to specify a minimum size 
#                       for the child widget in the direction of 
#                       the PanedWindow's orientation. For orient=
#                       tk.HORIZONTAL, this is the minimum width;
#                       for orient=tk.VERTICAL, it is the minimum height.

# padx                  The amount of extra space to be added to the left 
#                       and right of the child widget;

# sticky                This option functions like the sticky argument to 
#                       the .grid() method. The .grid() method It specifies 
#                       how to position a child widget if the pane is
#                       larger than the widget. For example, sticky=
#                       tk.NW would position the widget in the upper 
#                       left (“northwest”) corner of the pane.

# width                 Desired width of the child widget.
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
       pwInterna.remove(escala)            
       pwInterna.add(escala,after=btnAceptar)

            
    if (estado==2):
       pwInterna.remove(escala)            
       pwInterna.add(escala,before=btnAceptar)
           
    if (estado==3):       
       pwInterna.remove(escala)            
       pwInterna.add(escala,after=btnAceptar,padx=20)
         
    if (estado==4):           
       pwInterna.remove(escala)            
       pwInterna.add(escala,after=btnAceptar,pady=20)
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

# Crea el panedWindow
pwPrincipal = PanedWindow(vPrincipal,
                          bg="GREEN")

# Especifica la forma en que se empacan los objetos
pwPrincipal.pack(fill = BOTH, expand = 1)

# Crea un control de Entrada y lo agrega
txtDatos = Entry(pwPrincipal, bd = 5)
pwPrincipal.add(txtDatos)

# Crea otra pw
pwInterna = PanedWindow(pwPrincipal, 
                        orient = VERTICAL,
                        bg="red")

# La agrega a la paned window principal                        
pwPrincipal.add(pwInterna)

# Crea un objeto escala y lo agrega a la Interna
escala = Scale( pwInterna, orient = HORIZONTAL)
pwInterna.add(escala)

# Crea el botón de Aceptar y lo agrega a la Interna
btnAceptar = Button(pwInterna, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
# Lo agrega
pwInterna.add(btnAceptar) 
                      
# Ejecuta loop
vPrincipal.mainloop()