# Curso de Python - Tkinter
# A30 Atributo Dimensión

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A30_AtributosStandar")

# Se establece un tamaño
vPrincipal.geometry("600x400")    

# Variable para control de posicion
posicion = 1

def fnCambiaPos():
    # Indico que variable es global
    global posicion
            
    if (posicion==1):
       # A centimetros
       print("Posición en 5 Cms")
       btnCambiar.place(x = "5c",y = "5c")
              
    if (posicion == 2):  
       # A pulgadas
       print("Posición en 1 Pulgada")
       btnCambiar.place(x = "1i",y = "1i")
       
    if (posicion == 3):
       # A milimetros
       print("Posición en 55 Milimetros")
       btnCambiar.place(x = "55m",y = "55m")
    
    if (posicion == 4):   
       print("Posición en 35 Puntos de Impresora")
       btnCambiar.place(x = "35p",y = "35p")
       
    if (posicion == 5):   
       print("Posición en 20 Pixeles")
       btnCambiar.place(x = "20",y = "20")   

    # Incremento la posicion       
    posicion = posicion + 1
    
    if (posicion == 6):
       posicion = 1
                  

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar", 
                    command = fnCambiaPos)

# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)


# El Default de las dimensiones es pixeles
# c = centimetros
# i = pulgadas
# m = milímetros
# p = puntos de impresora (1/72")

# Ejecuta loop
vPrincipal.mainloop()