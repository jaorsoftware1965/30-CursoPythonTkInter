# Curso de Python - Tkinter
# A14 frame

# Antes de ver la segunda parte del ListBox, deberemos de ver el 
# widget frame, ya que este es indispensable en la implementación
# de una funcionalidad del ListBox

# Un frame es simplemente un widget que nos permite contener a otros
# elementos; y este frame a su vez puede estar dentro de una ventana 
# principal

# incluimos la libreria
from tkinter import *

# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A14 frame")

# Se establece un tamaño
vPrincipal.geometry("400x200")


# Creamos un Frame dentro de la ventana principal
frame = Frame (vPrincipal,	       # Ventana Principal
	            width=380,          # Ancho
	            height=180,         # Alto
               bg="blue")          # Color de Fondo

# Lo integramos a la ventana principal
frame.place(x=10,y=10)

# Creamos un Botón
redbutton = Button(frame, text = "Red", fg = "red")
redbutton.place(x=10,y=10)

greenbutton = Button(frame, text = "Brown", fg="brown")
greenbutton.place(x=10,y=50)

bluebutton = Button(frame, text = "Blue", fg = "blue")
bluebutton.place(x=10,y=90)

# Ciclo Principal
vPrincipal.mainloop()