# Curso de Python - Tkinter
# A26 PanedWindow

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A26 MenuButton")

# Se establece un tamaño
vPrincipal.geometry("600x400")    

# Crea el panedWindow
pwPrincipal = PanedWindow(vPrincipal,
                          bg="GREEN")

# Especifica la forma en que se empacan los objetos
pwPrincipal.pack(fill = BOTH, expand = 1)

# Crea un control de Entrada y lo agrega
txtDatos = Entry(pwPrincipal, bd = 5)
pwPrincipal.add(txtDatos)

# Crea otra pw
pwInterna = PanedWindow(pwPrincipal, 
                        orient = VERTICAL,
                        bg="red")

# La agrega a la paned window principal                        
pwPrincipal.add(pwInterna)

# Crea un objeto escala y lo agrega a la Interna
escala = Scale( pwInterna, orient = HORIZONTAL)
pwInterna.add(escala)

# Crea el botón de Aceptar y lo agrega a la Interna
btnAceptar = Button(pwInterna, text = "Aceptar")
pwInterna.add(btnAceptar)

# Ejecuta loop
vPrincipal.mainloop()