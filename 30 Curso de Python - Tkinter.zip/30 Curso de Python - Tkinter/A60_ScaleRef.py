# Curso de Python - Tkinter
# A60 Scale Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A60 Scale Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Propiedades para option
# activebackground
# bg or background
# bd or borderwidth
# command
# cursor              
# digits              The way your program reads the current value 
#                     shown in a scale widget is through a control 
#                     variable. The control variable for a scale 
#                     can be an IntVar,a DoubleVar (for type float),
#                     or a StringVar. If it is a string variable, 
#                     the digits option controls how many digits 
#                     to use when the numeric scale value is converted 
#                     to a string.
# font
# fg o foreground
# _from               A float value that defines one end of the scale's 
#                     range. For vertical scales, this is the top end; 
#                     for horizontal scales, the left end. The underbar
#                     (_) is not a typo: because from is a reserved 
#                     word in Python, this option is spelled
#                     from_. The default is 0.0. See the to option, 
#                     below, for the other end of the range.
# highlightbackground
# highlightcolor
# highlightthickness
# label               You can display a label within the scale widget 
#                     by setting this option to the label's text. The
#                     label appears in the top left corner if the scale 
#                     is horizontal,or the top right corner if vertical.
#                     The default is no label.
# length              The length of the scale widget. This is the
#                     x dimension if the scale is horizontal, or the
#                     y dimension if vertical. The default is 100 
#                     pixels. For allowable values
# orient              Set orient=tk.HORIZONTAL if you want the 
#                     scale to run along the x dimension, or orient
#                     =tk.VERTICAL to run parallel to the y-axis.
#                     Default is vertical
# relief              By default, a radiobutton will have tk.FLAT
# repeatdelay         This option controls how long button 1 has 
#                     to be held down in the trough before the slider
#                     starts moving in that direction repeatedly. 
#                     Default is repeatdelay=300, and the units are 
#                     milliseconds.
# repeatinterval      This option controls how often the slider 
#                     jumps once button 1 has been held down in 
#                     the trough for at least repeatdelay milliseconds.
#                     For example, repeatinterval=100 would jump the 
#                     slider every 100 milliseconds
# resolution          Normally, the user will only be able to 
#                     change the scale in whole units. Set this 
#                     option to some other value to change the 
#                     smallest increment of the scale's value. 
#                     For example, if from_=-1.0 and to=1.0, 
#                     and you set resolution=0.5, the scale will 
#                     have 5 possible values: -1.0, -0.5, 0.0, 
#                     +0.5, and +1.0. All smaller movements will 
#                     be ignored. Use resolution=-1 to disable
#                     any rounding of values.
# showvalue           Normally, the current value of the scale 
#                     is displayed in text form by the slider 
#                     (above it for horizontal scales, to the 
#                     left for vertical scales). Set this
#                     option to 0 to suppress that label.
# sliderlength        Normally the slider is 30 pixels along the 
#                     length of the scale. You can change that 
#                     length by setting the sliderlength
# sliderrelief        By default, the slider is displayed with 
#                     a tk.RAISED relief style.
# state 
# takefocus
# tickinterval        Normally, no “ticks” are displayed along 
#                     the scale. To display periodic scale 
#                     values, set this option to a number, 
#                     and ticks will be displayed on multiples of
#                     that value. For example, if from_=0.0, to=1.0,
#                     and tickinterval=0.25, labels will be displayed 
#                     along the scale at values 0.0, 0.25,
#                     0.50, 0.75, and 1.00. These labels appear 
#                     below the scale if horizontal, to its
#                     left if vertical. Default is 0, which 
#                     suppresses display of ticks.
# to                  A float value that defines one end of the scale's
#                     range; the other end is defined by the from_ 
#                     option, discussed above. The to value can be 
#                     either. greater than or less than the from_
#                     value. For vertical scales, the to value
#                     defines the bottom of the scale; for horizontal
#                     scales, the right end. The default value is 100.0.
# troughcolor         The color of the trough.
# variable            The control variable for this scale.
# width               The width of the trough part of the widget.
#                     This is the x dimension for vertical scales 
#                     and the y dimension if the scale has orient=
#                     tk.HORIZONTAL. Default is 15 pixels.

# Métodos
# .coords(value=None)
# Returns the coordinates, relative to the upper left corner of the widget, corresponding to a given
# value of the scale. For value=None, you get the coordinates of the center of the slider at its current
# position. To find where the slider would be if the scale's value were set to some value x, use value=x.

# .get()
# This method returns the current value of the scale.

# .identify(x, y)
# Given a pair of coordinates (x, y) relative to the top left corner of the widget, this method returns
# a string identifying what functional part of the widget is at that location. The return value may be
# any of these:
#    'slider' The slider.
#    'trough1' For horizontal scales, to the left of the slider; for vertical scales, above the slider.
#    'trough2' For horizontal scales, to the right of the slider; for vertical scales, below the slider.
#    '' Position (x, y) is not on any of the above parts.

# .set(value)
# Sets the scale's value.
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
       scale.config(command=fnObtenerValor)
       scale.config(length=150)
       scale.config(orient=HORIZONTAL)
       

    if (estado==2):
       scale.config(orient=VERTICAL)
       scale.config(sliderlength=10)
                  
    if (estado==3):       
       scale.set(5)
         
    if (estado==4):           
       scale.config(width=25)
       
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1
# Función para obtener el Valor
def fnObtenerValor(valor):
   
   # Obtiene el valor
   seleccion = "Valor = " + str(valor)
   
   # Lo coloca en la etiqueta
   scale.config(label = seleccion)
   
# Crea el panedWindow
pwPrincipal = PanedWindow(vPrincipal,
                          bg="GREEN")
                          
# Variable para controlar el Valor
var = DoubleVar()

# Crea el objeto Escala
scale = Scale( vPrincipal, 
               variable = var, 
               from_ = 1,
               to =10,
               orient = HORIZONTAL)
scale.pack()



# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
        
# Ubicamos el Botón                            
btnCambiar.place(x = 120,y = 120)
                      
# Ejecuta loop
vPrincipal.mainloop()