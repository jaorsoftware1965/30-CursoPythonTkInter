# Curso de Python - Tkinter
# A31 Atributo Color

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A31_AtributoColor")

# Se establece un tamaño
vPrincipal.geometry("600x400")    

# Variable para control de posicion
color = 1

# El Color puede establecerse de la siguiente forma
# rgb        4 bits por color
# rrggbb     8 bits por color
# rrrgggbbb 12 bits por color

def fnCambiaColor():
    # Indico que variable es global
    global color
            
    if (color==1):
       print("blue")
       btnCambiar.config(bg = "blue")
                  
    if (color==2):
       print("#00ff00")
       btnCambiar.config(bg = "#00ff00")   
    
    if (color==3):
       print("#0000ff")
       btnCambiar.config(bg = "#0000ff")   
       
    if (color==4):
       print("#ff0000")
       btnCambiar.config(bg = "#ff0000")       
       
    if (color==5):
       print("#0f0")
       btnCambiar.config(bg = "#0f0")          
    
    if (color==6):
       print("#000000fff")
       btnCambiar.config(bg = "#000000fff")              
              
    # Incremento el color
    color = color + 1
    
    if (color == 7):
       color = 1
                  

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar", 
                    command = fnCambiaColor)

# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)



# Ejecuta loop
vPrincipal.mainloop()