# Curso de Python - Tkinter
# A35 Atributo Cursor

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A35 Atributo Cursor")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Variable para cursor
cursor = 1

# -----------------------
# Valores posibles cursor
# arrow
# based_arrow_down
# based_arrow_up
# boat
# bogosity
# bottom_left_corner
# bottom_right_corner
# bottom_side
# bottom_tee
# box_spiral
# center_ptr
# circle
# clock
# coffee_mug
# cross
# cross_reverse
# crosshair
# diamond_cross
# dot
# dotbox
# double_arrow
# draft_large
# draft_small
# draped_box
# exchange
# fleur
# gobbler
# gumby
# hand1
# hand2
# heart
# icon
# iron_cross
# left_ptr
# left_side
# left_tee
# leftbutton
# ll_angle
# lr_angle
# man
# middlebutton
# mouse
# pencil
# pirate
# plus
# question_arrow
# right_ptr
# right_side
# right_tee
# rightbutton
# rtl_logo
# sailboat
# sb_down_arrow
# sb_h_double_arrow
# sb_left_arrow
# sb_right_arrow
# sb_up_arrow
# sb_v_double_arrow
# shuttle
# sizing
# spider
# spraycan
# star
# target
# tcross
# top_left_arrow
# top_left_corner
# top_right_corner
# top_side
# top_tee
# trek
# ul_angle
# umbrella
# ur_angle
# watch
# xterm
# X_cursor

def fnCambiaCursor():
    # Indico que variable es global
    global cursor
            
    if (cursor==1):       
       print("Cursor based_arrow_down")
       btnCambiar.config(cursor="based_arrow_down")

    if (cursor==2):       
       print("Cursor hand2")
       btnCambiar.config(cursor="hand2")

    if (cursor==3):       
       print("Cursor umbrella")
       btnCambiar.config(cursor="umbrella")

    if (cursor==4):       
       print("Cursor watch")
       btnCambiar.config(cursor="watch")

    if (cursor==5):       
       print("Cursor pencil")
       btnCambiar.config(cursor="pencil")
                     
              
    # Incremento la posicion       
    cursor = cursor + 1
    
    if (cursor == 6):
       cursor = 1
       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiaCursor)

# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)

# Ejecuta loop
vPrincipal.mainloop()