# Curso de Python - Tkinter
# A13 ListBox

# En esta clase veremos el uso del ListBox, comunmente conocido en la mayoría 
# de los lenguajes, el cual es un objeto que presenta una lista de opciones para 
# que el usuario pueda seleccionar una o varias.

# Para este objeto, las propiedades vistas anteriormente como Fuente, color, y
# demás, trabajan de igual forma. En esta clase veremos el uso de propiedades 
# especificas del control.

# Importa la librería
from tkinter import *

# Crea la Ventana Principal
vPrincipal = Tk()

# Coloca el Título
vPrincipal.title("A13 Listbox")

# Se establece un tamaño
vPrincipal.geometry("600x300")

        
# Crea el Objeto ListBox;
lstLenguajes = Listbox(vPrincipal,                 # Contenedor
                       exportselection=0,          # Permanece la seleccion
                       highlightcolor="yellow",    # Color cuando se tiene el foco
					       selectbackground="red",     # Color de fondo de la Selección
	                    selectmode = SINGLE)        # Modo de Operación
	                  
# Agrega las opciones al Objeto
lstLenguajes.insert(1, "Python")
lstLenguajes.insert(2, "Perl")
lstLenguajes.insert(3, "C")
lstLenguajes.insert(4, "PHP")
lstLenguajes.insert(5, "JSP","Ruby","Pascal")

# Agrega el objeto a la Ventana Principal
lstLenguajes.place(x=10,y=10)

# Creando otro listbox
lstSistemasOperativos = Listbox(vPrincipal,          # Contenedor
                       exportselection=0,          # Permanece la seleccion
	                   selectmode = MULTIPLE)  # Modo de Operación

# Creando una Tupla
items = ("Windows","Linux","Maintosh","Android")

# Agregando opciones desde una tupla
lstSistemasOperativos.insert(0, *items)

# Agrega el objeto a la Ventana Principal
lstSistemasOperativos.place(x=210,y=10)

# Imprimiendo el tamaño del listbox
print ("Elementos en lista de Lenguajes:",lstLenguajes.size())
print ("Elementos en lista de Sistemas Operativos:",lstSistemasOperativos.size())
print ()

# Obteniendo un Elemento en específico de la lista
print ("Lenguaje en posición 2:",lstLenguajes.get(2))
print ("Sistema Operativo en posición 1:",lstSistemasOperativos.get(1))
print ()

# Imprimiendo todos los elementos
print (lstLenguajes.get(0,END))
print (lstSistemasOperativos.get(0,END))
print ()

# Ciclo para acceder a los elementos
for xLenguaje in lstLenguajes.get(1,3):
    print(xLenguaje)
print()

# Ciclo para acceder a los elementos
for xSO in lstSistemasOperativos.get(1,3):
    print(xSO)
print()

# Ciclo Principal
vPrincipal.mainloop()