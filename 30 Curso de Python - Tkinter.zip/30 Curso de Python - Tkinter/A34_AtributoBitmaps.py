# Curso de Python - Tkinter
# A34 Atributo Bitmaps

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A34 Atributo Bitmpas")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Variable para bitmap
bitmap = 1

# Valores posibles bitmap:
# error, gray75, gray50, gray25, gray12, hourglass,
# info, questhead, question, warning

def fnCambiaRelieve():
    # Indico que variable es global
    global bitmap
            
    if (bitmap==1):       
       print("Bitmap error")
       btnCambiar.config(bitmap="error")
              
    if (bitmap == 2):  
       print("Bitmap gray75")
       btnCambiar.config(bitmap="gray75")
       
    if (bitmap == 3):
       print("Bitmap gray50")
       btnCambiar.config(bitmap="gray50")
    
    if (bitmap == 4):   
       print("Bitmap gray25")
       btnCambiar.config(bitmap="gray25")
       
    if (bitmap == 5):   
       print("Bitmap gray12")
       btnCambiar.config(bitmap="gray12")
    
    if (bitmap == 6):   
       print("Bitmap hourglass")
       btnCambiar.config(bitmap="hourglass")
       
    if (bitmap == 7):   
       print("Bitmap info")
       btnCambiar.config(bitmap="info")   
       
    if (bitmap == 8):   
       print("Bitmap questhead")
       btnCambiar.config(bitmap="questhead")      
    
    if (bitmap == 9):   
       print("Bitmap question")
       btnCambiar.config(bitmap="question")   

    if (bitmap == 10):   
       print("Bitmap warning")
       btnCambiar.config(bitmap="warning")          
              
    # Incremento la posicion       
    bitmap = bitmap + 1
    
    if (bitmap == 11):
       bitmap = 1
       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiaRelieve)

# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)

# Ejecuta loop
vPrincipal.mainloop()