# Curso de Python - Tkinter
# A36 Atributo Font

# Importamos la librería
from tkinter import *
from tkinter import font
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A36 Atributo Font")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Variable Global
fuente = 1

# Propiedades de las Fuentes
# family     El nombre de la fuente
# size       Entero en points. Para obtener una fuente de 
#            n pixeles de altura usar -n.
# weight     'bold' , 'normal' 
# slant      'italic', 'roman'.
# underline  1 para activar 0 normal.
# overstrike 1 para activar 0 normal

# Creamos una fuente
oFuente = font.Font(family='Arial', 
                    size=10, 
                    weight='bold',
                    slant='italic',
                    underline=1,
                    overstrike=1)


# Cambiar la Fuente
def fnCambiarFuente():
    # Indico que variable es global
    global fuente
            
    if (fuente==1):       
       oFuente = font.Font(family='Helvetica', 
                           size=12, 
                           weight='bold',
                           slant='italic',
                           underline=1,
                           overstrike=1)
       print("Font: Helvetica,12,bold,italic,1,1")
       btnCambiar.config(font=oFuente)

    if (fuente==2):       
       oFuente = font.Font(family='Arial', 
                           size=10, 
                           weight='normal',
                           slant='italic',
                           underline=0,
                           overstrike=1)
       print("Font: Arial,10,normal,italic,0,1")
       btnCambiar.config(font=oFuente)
       

    if (fuente==3):       
       oFuente = font.Font(family='Lucida Console', 
                           size=14, 
                           weight='bold',
                           slant='roman',
                           underline=1,
                           overstrike=0)
       print("Font: Lucida Console,14,bold,normal,1,0")
       btnCambiar.config(font=oFuente)
              
    # Incremento la posicion       
    fuente = fuente + 1
    
    if (fuente == 4):
       fuente = 1
       

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    #font = oFuente,
                    command = fnCambiarFuente)

# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)

# Ejecuta loop
vPrincipal.mainloop()