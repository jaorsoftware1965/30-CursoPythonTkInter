# Curso de Python - Tkinter
# A19 labelframe

# Un labelframe es similar al visto anteriormente, solo que este tiene
# un texto titular en la parte superior izquierda.

# Importamos la librería
from tkinter import *

# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A19 LabelFrame")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Creamos el LabelFrame y lo asignamos a la ventana|
labelframe = LabelFrame(vPrincipal, 
                        text = "LabelFrame",
                        bg="blue", #Color de Fondo
                        bd=2, # Ancho del Borde
                        fg="white", #Color del texto 
                        padx=15, #Relleno izq-der
                        pady=15, #Rellono arr-aba
                        relief=RAISED,#GROOVE,FLAT,RIDGE,SUNKEN
                        labelanchor="e",
                        height=200,
                        width=50
                        )
# Posiciones del labelanchor
#    nw      n      ne
# wn                     en                       
# 
# w                      e
#
# ws                     es
#    sw      s      se


# Lo hacemos que llene a ambos lados y que se expanda
labelframe.pack(fill = "both", expand = "yes")

# Creamos una etiqueta y la agregamos al LabelFrame 
etiqueta = Label(labelframe, text = "Etiqueta dentro del labelframe")
etiqueta.pack()

# Creamos otra etiqueta y la agregamos al LabelFrame 
etiqueta2 = Label(labelframe, text = "Otra Etiqueta dentro del labelframe")
etiqueta2.pack()


# Procesamiento de la ventana principal 
vPrincipal.mainloop()