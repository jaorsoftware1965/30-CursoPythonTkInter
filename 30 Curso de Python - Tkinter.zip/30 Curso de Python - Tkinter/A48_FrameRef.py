# Curso de Python - Tkinter
# A48 Frame Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A48 Frame Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Creación
# Frame(parent, option, ...)

# Propiedades
# bg or background      The frame's background color
# bd or borderwidth     Width of the frame's border. The default 
#                       is 0 (no border).
# cursor                The cursor used when the mouse is within 
#                       the frame widget
# height                The vertical dimension of the new frame. 
#                       This will be ignored unless you also call
#                       .grid_propagate(0) on the frame
# highlightbackground   Color of the focus highlight when the 
#                       frame does not have focus. 
# highlightcolor        Color shown in the focus highlight when 
#                       the frame has the focus.
# highlightthickness    Thickness of the focus highlight.
# padx                  Normally, a Frame fits tightly around its
#                       contents. To add N pixels of horizontal
#                       space inside the frame, set padx=N.
# pady                  Used to add vertical space inside a frame.
# relief                The default relief for a frame is tk.FLAT, 
#                       which means the frame will blend in with 
#                       its surroundings. To put a border around 
#                       a frame, set its border; width to a 
#                       positive value and set its relief to one 
#                       of the standard relief types.
# takefocus             Normally, frame widgets are not visited by 
#                       input focus. However, you can set 
#                       takefocus=1 if you want the frame to 
#                       receive keyboard input. To handle such 
#                       input, you will need to create bindings 
#                       for keyboard events.
# width                 The horizontal dimension of the new frame.
#                       This value be ignored unless you also call
#                       .grid_propagate(0) on the frame.


# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):     
       #Cambiamos el Cursor    
       frame.config(cursor="based_arrow_down")
    
    if (estado==2):       
       #Cambiamos la altura
       frame.config(height=500)
   
    if (estado==3):       
       #Cambiamos la altura
       frame.config(padx=50)   
    
    if (estado==4):       
       #Cambiamos la altura
       frame.config(bd=15)   
       frame.config(relief=GROOVE)   
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1
       

# Creamos un Frame dentro de la ventana principal
frame = Frame (vPrincipal,	       # Ventana Principal
	            width=380,          # Ancho
	            height=180,         # Alto
               bg="blue")          # Color de Fondo

# Lo integramos a la ventana principal
frame.place(x=10,y=10)
       
    
# Creamos un botón
btnCambiar = Button(frame, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)



# Ejecuta loop
vPrincipal.mainloop()