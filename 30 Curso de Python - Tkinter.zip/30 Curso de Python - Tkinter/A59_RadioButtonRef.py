# Curso de Python - Tkinter
# A59 RadioButton Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A59 RadioButton Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Propiedades para option
# activebackground
# activeforeground
# anchor              The default is anchor=tk.CENTER.  
# bg or background
# bitmap 
# bd or borderwidth
# command
# compound            If you specify both text and a graphic 
#                     (either a bitmap or an image), this
#                     option specifies where the graphic appears
#                     relative to the text. Possible values are 
#                     tk.NONE (the default value), tk.TOP, tk.BOTTOM,
#                     tk.LEFT, tk.RIGHT, and tk.CENTER. For example, 
#                     compound=tk.BOTTOM would position the graphic 
#                     below the text. If you specify compound=tk.NONE,
#                     the graphic is displayed but the text (if any) 
#                     is not.
# cursor              
# disabledforeground
# font
# fg o foreground
# height              En lineas
# highlightbackground
# highlightcolor
# highlightthickness
# image               The image appears when the radiobutton is 
#                     not selected; compare selectimage, below.
# indicatoron         Normally a radiobutton displays its indicator.
#                     If you set this option to zero, the indicator 
#                     disappears, and the entire widget becomes a 
#                     “push-push” button that looks raised when it 
#                     is cleared and sunken when it is set. You
#                     may want to increase the borderwidth value 
#                     to make it easier to see the state of such 
#                     a control.
# justify         
# offrelief           If you suppress the indicator by asserting 
#                     indicatoron=False, the offrelief option 
#                     specifies the relief style to be displayed 
#                     when the radiobutton is not selected. The 
#                     default values is tk.RAISED.
# overrelief          Specifies the relief style to be displayed 
#                     when the mouse is over the radiobutton.
# padx
# pady
# relief              By default, a radiobutton will have tk.FLAT
# selectcolor
# selectimage
# state
# takefocus
# text                The label displayed next to the radiobutton.
#                     Use newlines ('\n') to display multiple lines
#                     of text.
# textvariable        If you need to change the label on a radiobutton 
#                     during execution, create a StringVar
# underline
# value
# variable            The control variable that this radiobutton 
#                     shares with the other radiobuttons in the 
#                     group; this can be either an IntVar or a StringVar

   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
       rbC.config(relief=FLAT)

    if (estado==2):
       rbC.config(height=10)
                  
    if (estado==3):       
       rbC.config(foreground="RED")
         
    if (estado==4):           
       rbC.config(padx=5)
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

# Crea el panedWindow
pwPrincipal = PanedWindow(vPrincipal,
                          bg="GREEN")
# Carga la Imagen
img = PhotoImage(file='img/java-logo.png')

# Para obtener el radio seleccionado
def fnSeleccionado():        
    # Obtiene la Seleccion
    seleccion = "Seleccionaste la opción: " + str(var.get())
    
    # Coloca el texto en la etiqueta
    etqMensaje.config(text = seleccion)

# Variable var
var = IntVar()

# Crea los objetos
rbJava = Radiobutton(vPrincipal, 
                     text = "Java", 
                     variable = var, 
                     image = img,
                     value = 1,
                     command = fnSeleccionado)

# Lo coloca 
rbJava.pack(anchor = W)


rbC = Radiobutton(vPrincipal, 
                  text = "C++", 
                  variable = var, 
                  value = 2,
                  relief =SOLID,
                  command = fnSeleccionado)
# Lo Coloca                  
rbC.pack( anchor = W )

# Crea otro RadioButton
rbPhp = Radiobutton(vPrincipal, 
                    text = "Php", 
                    variable = var, 
                    value = 3,
                    command = fnSeleccionado)

# Lo coloca en West        
rbPhp.pack( anchor = W)

# Crea la etiqueta
etqMensaje = Label(vPrincipal)

# Coloca la etiqueta en East
etqMensaje.pack(anchor = E)   

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
        
# Ubicamos el Botón                            
btnCambiar.place(x = 120,y = 20)
                      
# Ejecuta loop
vPrincipal.mainloop()