# Curso de Python - Tkinter
# A61 ScrollBar Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A61 ScrollBar Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Propiedades para option
# activebackground
# activerelief
# bg or background
# bd or borderwidth
# command
# cursor              
# elementborderwidth
# highlightbackground
# highlightcolor
# highlightthickness
# jump                This option controls what happens when a user 
#                     drags the slider. Normally (jump=0), every 
#                     small drag of the slider causes the command 
#                     callback to be called. If you set this 
#                     option to 1, the callback isn't called until
#                     the user releases the mouse button.
# orient
# relief              
# repeatdelay         
# repeatinterval      
# takefocus
# troughcolor         The color of the trough.
# width               Default is 16

# Métodos

# .activate(element=None)
# If no argument is provided, this method returns one of the strings 'arrow1', 'arrow2', 'slider',
# or '', depending on where the mouse is. For example, the method returns 'slider' if the mouse
# is on the slider. The empty string is returned if the mouse is not currently on any of these three
# controls.
# To highlight one of the controls (using its activerelief relief style and its activebackground
# color), call this method and pass a string identifying the control you want to highlight, one of 'arrow1',
# 'arrow2', or 'slider'.

#.delta(dx, dy)
# Given a mouse movement of (dx, dy) in pixels, this method returns the float value that should
# be added to the current slider position to achieve that same movement. The value must be in the
# closed interval [-1.0, 1.0].

# .fraction(x, y)
# Given a pixel location (x, y), this method returns the corresponding normalized slider position
# in the interval [0.0, 1.0] that is closest to that location.

# .get()
# Returns two numbers (a, b) describing the current position of the slider. The a value gives the position
# of the left or top edge of the slider, for horizontal and vertical scrollbars respectively; the b
# value gives the position of the right or bottom edge. Each value is in the interval [0.0, 1.0] where 0.0
# is the leftmost or top position and 1.0 is the rightmost or bottom position. For example, if the slider
# extends from halfway to three-quarters of the way along the trough, you might get back the tuple
# (0.5,0.75).

# .identify(x, y)
# This method returns a string indicating which (if any) of the components of the scrollbar are under
# the given (x, y) coordinates. The return value is one of 'arrow1', 'trough1', 'slider',
# 'trough2', 'arrow2', or the empty string '' if that location is not on any of the scrollbar components.

#.set(first, last)
# To connect a scrollbar to another widget w, set w's xscrollcommand or yscrollcommand to the
# scrollbar's .set method. The arguments have the same meaning as the values returned by the
# .get() method. Please note that moving the scrollbar's slider does not move the corresponding
# widget.
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
       scrollbar.config(orient=HORIZONTAL)

    if (estado==2):
       scrollbar.config(background="BLUE")
                  
    if (estado==3):
       scrollbar.config(troughcolor="GREEN")
       scrollbar.config(orient=VERTICAL)
         
    if (estado==4):           
       scrollbar.config(width=25)
       
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1
     
# Creamos el ScrollBar
scrollbar = Scrollbar(vPrincipal)

# Insertamos el Scrollbar a la Derecha con Llenado Vertical
scrollbar.pack( side = RIGHT, fill = Y )

     
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
        
# Ubicamos el Botón                            
btnCambiar.place(x = 150,y = 120)
                      
# Ejecuta loop
vPrincipal.mainloop()