# Curso de Python - Tkinter
# A45 Canvas Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A45 Canvas Reference")

# Se establece un tamaño
vPrincipal.geometry("450x450")

# Método
# create_arc(x0, y0, x1, y1, option, ...)       Visto

# Propiedades

# activedash,           These options apply when the arc is in the
# activefill,           tk.ACTIVE state,that is, when the mouse
# activeoutline,        is over the arc. For example, the activefill
# activeoutlinestipple, option specifies the interior color when the 
# activestipple,        arc is active
# activewidth
# dash                  Dash pattern for the outline.
# dashoffset            Dash pattern offset for the outline.
# disableddash,         These options apply when the arc's state
# disabledfill,         is tk.DISABLED
# disabledoutline,
# disabledoutlinestipple,
# disabledstipple,
# disabledwidth          
# extent                Width of the slice in degrees. The slice
#                       starts at the angle given by the start 
#                       option and extends counterclockwise for
#                       extent degrees.
# fill                  By default, the interior of an arc is 
#                       transparent, and fill='' will select
#                       this behavior. You can also set this 
#                       option to any color and the interior
#                       of the arc will be filled with that color
# offset                Stipple pattern offset for the interior 
#                       of the arc
# outline               The color of the border around the outside 
#                       of the slice. Default is black
# outlineoffset         Stipple pattern offset for the outline
# outlinestipple        If the outline option is used, this 
#                       option specifies a bitmap used to stipple
#                       the border. Default is black, and that 
#                       default can be specified by setting 
#                       outlinestipple=''.
# start                 Starting angle for the slice, in degrees,
#                       measured from +x direction. If omitted, 
#                       you get the entire ellipse.
# state                 This option is tk.NORMAL by default. It 
#                       may be set to tk.HIDDEN to make the arc
#                       invisible or to tk.DISABLED to gray out 
#                       the arc and make it unresponsive to events
# stipple               A bitmap indicating how the interior fill
#                       of the arc will be stippled. Default is 
#                       stipple='' (solid). You'll probably want
#                       something like stipple='gray25'. Has no 
#                       effect unless fill has been set to some 
#                       color
# style                 The default is to draw the whole arc; use 
#                       style=tk.PIESLICE for this style. To draw
#                       only the circular arc at the edge of the 
#                       slice, use style=tk.ARC. To draw the 
#                       circular arc and the chord (a straight 
#                       line connecting the endpoints of the arc),
#                       use style=tk.CHORD.
# tags                  If a single string, the arc is tagged 
#                       with that string. Use a tuple of strings
#                       to tag the arc with multiple tags
# width                 Width of the border around the outside of 
#                       the arc. Default is 1 pixel.

# Metodo para crear una linea
# create_line(x0, y0, x1, y1, ..., xn, yn, option, ...)

# Propiedades
# activedash,           These options specify the dash, fill, 
# activefill,           stipple, and width values to be used
# activestipple,        when the line is active, that is,
# activewidth           when the mouse is over it.
# arrow                 The default is for the line to have no 
#                       arrowheads. Use arrow=tk.FIRST to get
#                       an arrowhead at the (x0, y0) end of the
#                       line. Use arrow=tk.LAST to get an 
#                       arrowhead at the far end. Use arrow=
#                       tk.BOTH for arrowheads at both ends.
# arrowshape            A tuple (d1, d2, d3) that describes the
#                       shape of the arrowheads added by the 
#                       arrow option. Default is (8,10,3).
# capstyle              You can specify the shape of the ends 
#                       of the line with this option.
# dash                  To produce a dashed line, specify this 
#                       option. The default appearance is a solid 
#                       line.
# dashoffset            If you specify a dash pattern, the default 
#                       is to start the specified pattern at the
#                       beginning of the line. The dashoffset 
#                       option allows you to specify that the
#                       start of the dash pattern occurs at a 
#                       given distance after the start of the line.
# disableddash,         The dash, fill, stipple, and width values
# disabledfill,         to be used when the item is in the 
# disabledstipple,      tk.DISABLED state
# disabledwidth
# fill                  The color to use in drawing the line. 
#                       Default is fill='black'.
# joinstyle             For lines that are made up of more than 
#                       one line segment, this option controls
#                       the appearance of the junction between 
#                       segments
# offset                For stippled lines, the purpose of this
#                       option is to match the item's stippling
#                       pattern with those of adjacent objects
# smooth                If true, the line is drawn as a series 
#                       of parabolic splines fitting the point 
#                       set. Default is false, which renders the
#                       line as a set of straight segments.
# splinesteps           If the smooth option is true, each spline
#                       is rendered as a number of straight line
#                       segments. The splinesteps option specifies
#                       the number of segments used to approximate
#                       each section of the line; the default is 
#                       splinesteps=12.
# state                 Normally, line items are created in state
#                       tk.NORMAL. Set this option to tk.HIDDEN 
#                       to make the line invisible; set it to 
#                       tk.DISABLED to make it unresponsive
#                       to the mouse.
# stipple               To draw a stippled line, set this option
#                       to a bitmap that specifies the stippling
#                       pattern, such as stipple='gray25'. 
# tags                  If a single string, the line is tagged 
#                       with that string. Use a tuple of strings
#                       to tag the line with multiple tags
# width                 The line's width. Default is 1 pixel.

# Creando un rectángulo en el CANVAS
# create_rectangle(x0, y0, x1, y1, option, ...)

# Propiedades           These options specify the appearance of 
# activedash,           the rectangle when its state is tk.ACTIVE,
# activefill,           that is, when the mouse is on top of the
# activeoutline,        rectangle.
# activeoutlinestipple,
# activestipple,
# activewidth
# dash                  To produce a dashed border around the 
#                       rectangle, use this option to specify a 
#                       dash pattern.
# dashoffset            Use this option to start the border's 
#                       dash pattern at a different point in
#                       the cycle.
# disableddash,         These options specify the appearance of 
# disabledfill,         the rectangle when its state is tk.DISABLED
# disabledoutline,
# disabledoutlinestipple,
# disabledstipple,
# disabledwidth
# fill                  By default, the interior of a rectangle 
#                       is empty, and you can get this behavior 
#                       with fill=''. You can also set the option
#                       to a color
# offset                Use this option to change the offset of 
#                       the interior stipple pattern.
# outline               The color of the border. Default is 
#                       outline='black'.
# outlineoffset         Use this option to adjust the offset of 
#                       the stipple pattern in the outline.
# moutlinestipple       Use this option to produce a stippled 
#                       outline. The pattern is specified by a 
#                       bitmap
# state                 By default, rectangles are created in the 
#                       tk.NORMAL state. The state is tk.ACTIVE 
#                       when the mouse is over the rectangle. Set
#                       this option to tk.DISABLED to gray out 
#                       the rectangle and make it unresponsive to
#                       mouse events
# stipple               A bitmap indicating how the interior of 
#                       the rectangle will be stippled. Default 
#                       is stipple='', which means a solid color.
#                       A typical value stipple would be stipple
#                       ='gray25'. Has no effect unless the fill
#                       has been set to some color.
# tags                  If a single string, the rectangle is 
#                       tagged with that string. Use a tuple of 
#                       strings to tag the rectangle with multiple
#                       tags
# width                 Width of the border. Default is 1 pixel.
#                       Use width=0 to make the border invisible


# Método para crear imagenes
# create_image(x, y, option, ...)

# Propiedades
# activeimage           Image to be displayed when the mouse is 
#                       over the item. For option values, see 
#                       image below.
# anchor                The default is anchor=tk.CENTER, meaning
#                       that the image is centered on the (x,y) 
#                       position. For example, if you specify 
#                       anchor=tk.S, the image will be positioned
#                       so that point (x, y) is located at the 
#                       center of the bottom (south) edge of the
#                       image
# disabledimage         Image to be displayedwhen the itemis inactive
# image                 The image to be displayed
# state                 Normally, image objects are created in 
#                       state tk.NORMAL. Set this value to 
#                       tk.DISABLED to make it grayed-out and 
#                       unresponsive to the mouse. If you set it
#                       to tk.HIDDEN, the item is invisible
# tags                  If a single string, the image is tagged 
#                       with that string. Use a tuple of strings
#                       to tag the image with multiple tags.



# Crea el objeto canvas
xCanvas = Canvas(vPrincipal,   # Ventana Padre
	              bg = "blue",  # Color de Fondo
	              height = 400, # Alto
	              width =400)   # Ancho

# Creamos un arc
arc = xCanvas.create_arc(10,10,240,210,        # coordenadas
                         start = 0,    # Incio del arco 
                         extent = 180, # fin del arco
                         outline = "green", 
                         dash = (150,121,131,141),
                         fill = "red") # color del arco


# Dibujamos una línea
line = xCanvas.create_line(10,10,200,200,  # coordenadas
                          arrow = FIRST,
	                       fill = 'white') # color de la linea


# Dibujamos un cuadrado
cuadrado = xCanvas.create_rectangle(10,150,200,200,  # coordenadas
                          stipple="gray25",
	                       fill = 'white') # color de la linea


# Cargamos una imagen
imgArchivo = PhotoImage(file = "img/jaorsoftware.png")
imgArchivo2= PhotoImage(file = "img/ico_aceptar.png")
image = xCanvas.create_image(250, 250,  
                             image = imgArchivo,
                             activeimage = imgArchivo2)

# Agregamos el objeto a la Ventana
xCanvas.pack()


# Ejecuta loop
vPrincipal.mainloop()