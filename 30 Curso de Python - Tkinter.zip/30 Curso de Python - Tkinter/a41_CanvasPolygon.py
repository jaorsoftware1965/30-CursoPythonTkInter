# Curso de Python - Tkinter
# A41 Canvas Polygon

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A41 Canvas Polygon")

# Se establece un tamaño
vPrincipal.geometry("450x450")

# Métodos
# create_polygon()

# Crea el objeto canvas
xCanvas = Canvas(vPrincipal,   # Ventana Padre
	              bg = "blue",  # Color de Fondo
	              height = 400, # Alto
	              width =400)   # Ancho

# Crea un poligono
# create_poligon((x0, y0),(x1, y1),..., option, ...)

# Atributos
# activedash, activefill, activeoutline, outactiveoutlinestipple
# activestipple, activewidth

# These options specify the appearance of the polygon when it is
# in the tk.ACTIVE state, that is, when the mouse is over it. For
# option values, see dash, fill, outline, outlinestipple, stipple, 
# and width.

# dash             To produce a dashed border around the oval, 
#                  set this option to a dash pattern
# dashoffset       When using the dash option, the dashoffset 
#                  option is used to change the alignment of the
#                  border's dash pattern relative to the oval.

# disableddash, disabledfill, disabledoutline, disabledoutlinestipple
# disabledstipple, disabledwidth

# These options specify the appearance of the polygon when the item's 
# state is tk.DISABLED

# fill             The default appearance of an oval's interior 
#                  is transparent, and a value of fill='' will 
#                  select this behavior. You can also set this 
#                  option to fill any color and the interior of 
#                  the ellipse will be filled with that color
# joinstyle        This option controls the appearance of the 
#                  intersections between adjacent sides of the 
#                  polygon.
# offset           Stipple pattern offset of the interior. 
# outline          Color of the outline; defaults to outline='',
#                  which makes the outline transparent.
# outlineoffset    Stipple pattern offset of the border. 
# outlinestipple   Use this option to get a stippled border around
#                  the polygon. The option value must be a bitmap
# smooth           The default outline uses straight lines to 
#                  connect the vertices; use smooth=0 to get that
#                  behavior. If you use smooth=1, you get a 
#                  continuous spline curve. Moreover, if you set
#                  smooth=1, you can make any segment straight 
#                  by duplicating the coordinates at each end of
#                  thatsegment.
# splinesteps      If the smooth option is true, each spline is 
#                  rendered as a number of straight line segments.
#                  The splinesteps option specifies the number
#                  splinesteps of segments used to approximate 
#                  each section of the line; the default is 
#                  splinesteps=12.
# state            By default, polygons are created in the 
#                  tk.NORMAL state. Set this option to tk.HIDDEN
#                  to make the polygon invisible, or set it to 
#                  tk.DISABLED to make it unresponsive to the 
#                  mouse.
# stipple          A bitmap indicating how the interior of the 
#                  polygon will be stippled. Default is 
#                  stipple='', which means a solid color. 
#                  A typical value would be stipple='gray25'.
#                  Has no effect unless the fill has been set to
#                  some color. 
# tags             If a single string, the oval is tagged with 
#                  that string. Use a tuple of strings to tag the
#                  oval with multiple tags.
# width            Width of the border around the outside of the
#                  ellipse. Default is 1 pixel; If you set this
#                  to zero, the border will not appear. If you 
#                  set this to zero and make the fill transparent,
#                  you can make the entire oval disappear

# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):       
       # Creamos un ovalo
       oval = xCanvas.create_polygon(10,10,    # Puntos
                                     250,10,
                                     250,150,
                                     10,150,
                                     fill="white")
    
    if (estado==2):       
       # Creamos un ovalo
       oval = xCanvas.create_polygon(10,10,
                                     250,10,
                                     10,150,
                                     250,150,
	                                  fill = "yellow") # color del arco
        
    if (estado==3):       
       # Creamos un ovalo
       oval = xCanvas.create_polygon(10,10,
                                     10,150,
                                     250,10,                                     
	                                  fill = "green") # color del arco
            
    # Incremento estado
    estado = estado + 1
    
    if (estado == 4):
       estado = 1

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                    
# Ubicamos el Botón                            
btnCambiar.place(x = 205,y = 410)
                 
# Agregamos el objeto a la Ventana
xCanvas.pack()

# Ejecuta loop
vPrincipal.mainloop()