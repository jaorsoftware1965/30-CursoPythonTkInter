# Curso de Python - Tkinter
# A27 MessageBox

# Importamos la librería
from tkinter import *
from tkinter import messagebox
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A26 MenuButton")

# Se establece un tamaño
vPrincipal.geometry("600x400")    


#Definimos una funcion para Mensaje
def fnMensaje():
    # Desplegamos el MessageBox
    messagebox.showinfo("Título", 
                        "Mensaje",
                        icon="otro")
                        #error,info,question,warning

# Creamos un botón
btnDesplegarMsgBox = Button(vPrincipal, 
                            text = "Desplegar MsgBox", 
                            command = fnMensaje)

# Ubicamos el Botón                            
btnDesplegarMsgBox.place(x = 35,y = 50)

# Ejecuta loop
vPrincipal.mainloop()