# Curso de Python - Tkinter
# A03 Eventos de Ventana

# En esta clase veremos como controlar el Evento de Cierre de una Ventana y tambien
# cuando esta es dimensionada; e inclusive cuando obtiene el foco.

# Se importa la librería
import tkinter

# Creamos la Ventana
vPrincipal = tkinter.Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("A03 Eventos de Ventana")

# Define la Función de Cerrado
def fnCerrar():
    # Mensaje de que has cerrado la Ventana
    print("Has Cerrado la Ventana")
    #Destruye el objeto
    #vPrincipal.destroy()

# Define la función para redimensionamiento
def fnRedimensionar(eventos):
    print(eventos)
    print("Has redimensionado la Ventana")

# Define la Función para el Evento de Cerrar la Ventana
vPrincipal.protocol("WM_DELETE_WINDOW",fnCerrar)
# WM_DELETE_WINDOW (the window is about to be deleted)
# WM_SAVE_YOURSELF (called by X window managers when the application should save a snapshot of its working set) 
# WM_TAKE_FOCUS    (called by X window managers when the application receives focus).

# Controla el Redimensionamiento de la Ventana
vPrincipal.bind("<Configure>", fnRedimensionar)

# Despliegua la Ventana y ejecuta el loop principal que controla la aplicación
vPrincipal.mainloop()
