# Curso de Python - Tkinter
# A55 MenuButton Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A55 MenuButton Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Menu item coption values
# activebackground      The background color when the mouse 
#                       is over the menubutton. 
# activeforeground      The foreground color when the mouse 
#                       is over the menubutton
# anchor                This options controls where the text 
#                       is positioned if the widget has more
#                       space than the text needs. The default
#                       is anchor=tk.CENTER, which centers
#                       the text. For other options. For example,
#                       if you use anchor=tk.W, the text would be
#                       centered against the left side of the widget.
# bg or background      The background color when the mouse is 
#                       not over the menubutton.
# bitmap                To display a bitmap on the menubutton, set 
#                       this option to a bitmap name
# bd or borderwidth     Width of the border around the menubutton. 
#                       Default is two pixels
# compound              If you specify both text and a graphic 
#                       (either a bitmap or an image), this option
#                       specifies where the graphic appears relative
#                       to the text. Possible values are tk.NONE 
#                       (the default value), tk.TOP, tk.BOTTOM, 
#                       tk.LEFT, tk.RIGHT, and tk.CENTER. For 
#                       example, compound=tk.RIGHT would position 
#                       the graphic to the right of the text. If 
#                       you specify compound=tk.NONE, the graphic 
#                       is displayed but the text (if any) is not.
# cursor                The cursor that appears when the mouse 
#                       is over this menubutton
# direction             Normally, the menu will appear below the
#                       menubutton. Set direction=tk.LEFT to display
#                       the menu to the left of the button; use 
#                       direction=tk.RIGHT to display the menu 
#                       to the right of the button; or use 
#                       direction='above' to place the menu above
#                       the button.
# disabledforeground    The foreground color shown on this menubutton 
#                       when it is disabled
# fg or foreground      The foreground color when the mouse is not 
#                       over the menubutton
# font                  Specifies the font used to display the text
# height                The height of the menubutton in lines of 
#                       text (not pixels!). The default is to fit
#                       the menubutton's size to its contents.
# highlightbackground   Color of the focus highlight when the widget
#                       does not have focus
# highlightcolor        Color shown in the focus highlight when the 
#                       widget has the focus.
# highlightthickness    Thickness of the focus highlight
# image                 To display an image on this menubutton, set 
#                       this option to the image object
# justify               This option controls where the text is located 
#                       when the text doesn't fill the menubutton: 
#                       use justify=tk.LEFT to left-justify the text 
#                       (this is the default);use justify=tk.CENTER 
#                       to center it, or justify=tk.RIGHT to right-
#                       justify.
# menu                  To associate the menubutton with a set of 
#                       choices, set this option to the Menu object
#                       containing those choices. That menu object 
#                       must have been created by passing the associated 
#                       menubutton to the constructor as its first
#                       argument. See below for an example showing 
#                       how to associate a menubutton and menu
# padx                  How much space to leave to the left and 
#                       right of the text of the menubutton. Default
#                       is 1.
# pady                  How much space to leave above and below 
#                       the text of the menubutton. Default is 1.
# relief                Normally, menubuttons will have tk.RAISED
#                       appearance
# state                 Normally, menubuttons respond to the mouse. 
#                       Set state=tk.DISABLED to gray out the menubutton
#                       and make it unresponsive.
# takefocus             Normally, menubuttons do not take keyboard 
#                       focus. Use takefocus=True to add the menubutton
#                       to the focus traversal order
# text                  To display text on the menubutton, set this option
#                       to the string containing the desired text.
#                       Newlines ('\n') within the string will cause line 
#                       breaks.
# textvariable          You can associate a control variable of class 
#                       StringVar with this menubutton. Setting that 
#                       control variable will change the displayed text.
# underline             Normally, no underline appears under the text 
#                       on the menubutton. To underline one of the 
#                       characters, set this option to the index of 
#                       that character
# width                 Width of the menubutton in characters (not 
#                       pixels!). If this option is not set, the label
#                       will be sized to fit its contents.



# Función que Procesa Menu
def fnProcesaMenu():   
   print ("Procesando Menu")

# Función que Sale
def fnSalir(event):   
   print("Salida 1")
   sys.exit(0)

# Función que Sale
def fnSalir2():   
   print("Salida 2")
   sys.exit(0)
      
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
        mb.config(background="yellow")
        mb.config(foreground="red")
            
    if (estado==2):
        mb.config(text="Nvo Texto")
   
    if (estado==3):       
        mb.config(height=5)
         
    if (estado==4):               
        mb.config(width=50)
        
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

                       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 120,y = 120)

# Creamos el MenuButton
mb = Menubutton(vPrincipal,text='Lenguajes',relief=RAISED)
mb.grid()
mb.menu = Menu(mb, tearoff=0)
mb['menu'] = mb.menu
cVar      = IntVar()
javaVar   = IntVar()
pythonVar = IntVar()
mb.menu.add_checkbutton(label='C++',variable=cVar)
mb.menu.add_checkbutton(label='Java',variable=javaVar)
mb.menu.add_checkbutton(label='Python',variable=pythonVar)


# Ejecuta loop
vPrincipal.mainloop()