# Curso de Python - Tkinter
# A21 Radio Button

# Importamos la librería
from tkinter import *

# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A21 RadioButton")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Carga la Imagen
img = PhotoImage(file='img/java-logo.png')

# Para obtener el radio seleccionado
def fnSeleccionado():        
    # Obtiene la Seleccion
    seleccion = "Seleccionaste la opción: " + str(var.get())
    
    # Coloca el texto en la etiqueta
    etqMensaje.config(text = seleccion)

# Variable var
var = IntVar()

# Crea los objetos
rbJava = Radiobutton(vPrincipal, 
                     text = "Java", 
                     variable = var, 
                     image = img,
                     value = 1,
                     command = fnSeleccionado)

# Lo coloca 
rbJava.pack(anchor = W)

# Valores posible para anchor
#
# NW          N        NE
#
#
# W        CENTER       E
#
#
# SW          S        SE

rbC = Radiobutton(vPrincipal, 
                  text = "C++", 
                  variable = var, 
                  value = 2,
                  command = fnSeleccionado)
# Lo Coloca                  
rbC.pack( anchor = W )

# Crea otro RadioButton
rbPhp = Radiobutton(vPrincipal, 
                    text = "Php", 
                    variable = var, 
                    value = 3,
                    command = fnSeleccionado)

# Lo coloca en West        
rbPhp.pack( anchor = W)

# Crea la etiqueta
etqMensaje = Label(vPrincipal)

# Coloca la etiqueta en East
etqMensaje.pack(anchor = E)    
        
# Procesamiento de la ventana principal 
vPrincipal.mainloop()