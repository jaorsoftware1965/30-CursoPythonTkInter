# Curso de Python - Tkinter
# A12 CheckButton II

# En esta clase veremos el uso de algunas otras propiedades del CheckButton, como lo es
# colocar una imagen, y que esta cambie dependiendo de su estado; y vamos a ver como
# habilitarlo y deshabilitarlo; así como establecer su estado de activo y desactivo.

# Importamos la librería
from tkinter import *

# Definimos la Ventana Principal    
vPrincipal = Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("12 CheckButton II")

# Se establece un tamaño
vPrincipal.geometry("300x300")


# Variable de Control
chkVar = IntVar()

# Cargamos la imagen a colocar en el buttón
imgAceptar = PhotoImage(file="img/ico_aceptar.png")

# Cargamos la imagen a colocar en el buttón
imgDisabled = PhotoImage(file="img/ico_disabled.png")

# Creamos el CheckButton de Sonido
chkButton = Checkbutton(vPrincipal, 
                        image = imgDisabled,
                        variable = chkVar,
                        selectimage = imgAceptar,                        
                        state = DISABLED,
                        height= 25,
                        width = 50)


# Ubica el CheckButton
chkButton.place(x=10, y = 10)

# Función para activar el botón
def fnChkButtonOn():    
    chkButton.select()
    chkButton['state'] = NORMAL    

def fnChkButtonOff():    
    chkButton.deselect()
    chkButton['state'] = DISABLED    

def fnChkButtonToggle():    
    chkButton.toggle()
    if (chkVar.get()==1):
        chkButton['state'] = NORMAL    
    else:    
        chkButton['state'] = DISABLED

# Crea el Botón para Seleccionar
btnSeleccionar = Button(vPrincipal,                   # Ventana Padre
                        command = fnChkButtonOn,      # Función a ejecutar
                        text = "Activar")             # Texto del Botón

# Ubica el Botón 
btnSeleccionar.place(x=20, y = 50)

# Crea el Botón para DesSeleccionar
btnDesSeleccionar = Button(vPrincipal,                   # Ventana Padre
                           command = fnChkButtonOff,     # Función a ejecutar
                           text = "DesActivar")          # Texto del Botón

# Ubica el Botón de DesSeleccionar
btnDesSeleccionar.place(x=120, y = 50)

# Crea el Botón para toggle
btnToggle = Button(vPrincipal,                   # Ventana Padre
                   command = fnChkButtonToggle,     # Función a ejecutar
                   text = "Toggle")              # Texto del Botón

# Ubica el Botón de DesSeleccionar
btnToggle.place(x=220, y = 50)


# El Loop Principal
vPrincipal.mainloop()