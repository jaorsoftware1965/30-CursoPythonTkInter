# Curso de Python - Tkinter
# A33 Atributo Relieves

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A33 Atributo Relieves")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Variable para relieve
relieve = 1

# Valores posibles relieve:
# FLAT, RAISED, SUNKEN, GROOVE,RIDGE, SOLID

def fnCambiaRelieve():
    # Indico que variable es global
    global relieve
            
    if (relieve==1):       
       print("Relieve FLAT")
       btnCambiar.config(relief=FLAT)
              
    if (relieve == 2):  
       print("Relieve Raised")
       btnCambiar.config(relief=RAISED)
       
    if (relieve == 3):
       print("Relieve SUNKEN")
       btnCambiar.config(relief=SUNKEN)
    
    if (relieve == 4):   
       print("Relieve GROOVE")
       btnCambiar.config(relief=GROOVE)
       
    if (relieve == 5):   
       print("Relieve RIDGE")
       btnCambiar.config(relief=RIDGE)
    
    if (relieve == 6):   
       print("Relieve SOLID")
       btnCambiar.config(relief=SOLID)    
              
    # Incremento la posicion       
    relieve = relieve + 1
    
    if (relieve == 7):
       relieve = 1
       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar", 
                    command = fnCambiaRelieve)

# Ubicamos el Botón                            
btnCambiar.place(x = 20,y = 20)

# Ejecuta loop
vPrincipal.mainloop()