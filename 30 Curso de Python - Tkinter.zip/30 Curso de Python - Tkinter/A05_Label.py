# Curso de Python - Tkinter
# A05 Label

# En esta clase veremos como crear objetos Label, como configurar su color; texto, ancho, alto, borde
# y ubicacion dentro de su contenedor que es la Ventana Principal

# Se importa la librería
import tkinter

# Importa StringVar del Módulo
from tkinter import *
#from tkinter import StringVar
#from tkinter import Label
#from tkinter import RAISED
#from tkinter import GROOVE
#from tkinter import RIDGE
#from tkinter import LEFT
#from tkinter import X

# Creamos la Ventana
vPrincipal = tkinter.Tk()

# Establecemos un tamaño
vPrincipal.geometry("800x600+10+10")

# Colocamos el Título de la Ventana
vPrincipal.title("A05 Label")

# Obtiene una variable
xString = StringVar()

# Coloca el texto a la variable
xString.set("Texto en un Label")

# Variable para el Color
xColor = "#%02x%02x%02x" % (128, 192, 200)

# Crea el Objeto Label
lblMensaje = Label(vPrincipal,             # Objeto Padre
                   textvariable = xString, # Variable Asociada al Texto
                   bg="blue",              # Color de Fondo
                   fg = xColor,            # Color de Texto
                   relief = RAISED )       # Tipo de Borde SUNKEN, RAISED, GROOVE, RIDGE, and FLAT


# Asocia la variable a su contenedor
lblMensaje.pack(fill=BOTH)
#lblMensaje.pack()

# Obtiene una variable
xString2 = StringVar()

# Coloca el texto a la variable
xString2.set("Texto en un segundo Label")

# Creando un Objeto para la Fuente
xFont = ("Helvetica", 10, "bold italic")

# Crea el Objeto Label
lblMensaje2 = Label(vPrincipal,             # Objeto Padre
                   textvariable = xString2, # Variable Asociada al Texto
                   font = xFont,            # Establecliendo la Fuente
                   bg="red",                # Color de Fondo
                   fg = "white",            # Color de Texto
                   padx=5,                  # Padx
                   pady=5,                  # Pady
                   relief = GROOVE )        # Tipo de Borde SUNKEN, RAISED, GROOVE, RIDGE, and FLAT

# Coloca en la Ventana Principal
lblMensaje2.pack()


# Obtiene una variable
xString3 = StringVar()

# Coloca el texto a la variable
xString3.set("Texto en un tercer Label")

# Crea el Objeto Label
lblMensaje3 = Label(vPrincipal,             # Objeto Padre
                   textvariable = xString3, # Variable Asociada al Texto
                   bg="green",              # Color de Fondo
                   height=5,                # Altura en Texto
                   width=25,                # Ancho en Texto
                   relief = RIDGE )         # Tipo de Borde SUNKEN, RAISED, GROOVE, RIDGE, and FLAT

# Coloca en la Ventana Principal
lblMensaje3.pack()

# Despliegua la Ventana y ejecuta el loop principal que controla la aplicación
vPrincipal.mainloop()

