# Curso de Python - Tkinter
# A64 TopLevel Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A64 Top Level Reference")

# Se establece un tamaño
vPrincipal.geometry("400x400")

# Constructor
# tk.Toplevel(option, ...)

# Propiedades para option
# bg or background
# bd or borderwidth
# class_                You can give a Toplevel window a “class” name.
#                       Such names are matched against the option 
#                       database, so your application can pick up 
#                       the user's configuration preferences (such 
#                       as colors) by class name. For example, you
#                       might design a series of pop-ups called 
#                       “screamers,” and set them all up with 
#                       class_='Screamer'. Then you can put a line 
#                       in your option database like this:
#                       *Screamer*background: red and then, if you 
#                       use the .option_readfile() method to read 
#                       your option database, all widgets with that 
#                       class name will default to a red background.
#                       This option is named class_ because class is 
#                       a reserved word in Python.
# cursor 
# height
# highlightbackground   
# highlightcolor
# highlightthickness
# menu                  To provide this window with a top-level menubar,
#                       supply a Menu widget as the value of this option.
#                       Under MacOS, this menu will appear at the top
#                       of the screen when the window is active. Under
#                       Windows or Unix, it will appear at the top of 
#                       the application.
# padx
# pady
# relief
# takefocus
# width                 The width of the window


# Métodos
# .aspect(nmin, dmin, nmax, dmax)
# Constrain the root window's width:length ratio to the range [ nmin / dmin, nmax / dmax ].

# .deiconify()
# If this window is iconified, expand it.

# .geometry(newGeometry=None)
# Set the window geometry. For the form of the argument, see Section 5.10, “Geometry strings” (p. 15).
# If the argument is omitted, the current geometry string is returned.

# .iconify()
# Iconify the window.

# .lift(aboveThis=None)
# To raise this window to the top of the stacking order in the window manager, call this method with
# no arguments. You can also raise it to a position in the stacking order just above another Toplevel
# window by passing that window as an argument.
   
# Variable Global
estado = 1

# Función que Procesa Menu
def fnProcesaMenu():
   # Despliega un Mensaje
   print ("Menu")

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
       ventanaTop.config(background="RED")
       
    if (estado==2):
       ventanaTop.config(width=250)
       ventanaTop.config(height=250)
                  
    if (estado==3):
       ventanaTop.iconify()
         
    if (estado==4):           
       ventanaTop.deiconify()
       ventanaTop.config(menu=menubar)
       
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

# Creamos la barra del Menu en vPrincipal
menubar = Menu(vPrincipal)

# Creamos un Menu para File
filemenu = Menu(menubar, tearoff = 0)

# Crea las opciones
filemenu.add_command(label = "Crear", command = fnProcesaMenu)
filemenu.add_command(label = "Abrir", command = fnProcesaMenu)
filemenu.add_command(label = "Guardar", command = fnProcesaMenu)
filemenu.add_command(label = "Guardar como...", command = fnProcesaMenu)
filemenu.add_command(label = "Cerrar", command = fnProcesaMenu)

# Añade un Separador
filemenu.add_separator()

# Añade la opción Salida y la asocia a un comando
filemenu.add_command(label = "Salir", command = vPrincipal.quit)

# Asocia el Menu a la Barra
menubar.add_cascade(label = "Archivo", menu = filemenu)

# Crea el Menu de Edición
editmenu = Menu(menubar, tearoff=0)

# Añade las opciones
editmenu.add_command(label = "Deshacer", command = fnProcesaMenu)

# Añade un separador
editmenu.add_separator()

# Añade mas opciones
editmenu.add_command(label = "Cortar", command = fnProcesaMenu)
editmenu.add_command(label = "Copiar", command = fnProcesaMenu)
editmenu.add_command(label = "Pegar", command = fnProcesaMenu)
editmenu.add_command(label = "Borrar", command = fnProcesaMenu)
editmenu.add_command(label = "Seleccionar todo", command = fnProcesaMenu)

# Añade el Menu a la barra
menubar.add_cascade(label = "Edicion", menu = editmenu)

# Crea el Menu de Ayuda
helpmenu = Menu(menubar, tearoff=0)

# Agrega las opciones
helpmenu.add_command(label = "Help Index", command = fnProcesaMenu)
helpmenu.add_command(label = "About...", command = fnProcesaMenu)

# Agrega el Menu a la Barra
menubar.add_cascade(label = "Ayuda", menu = helpmenu)

# Agrega a la ventana principal la Barra de Menu
#vPrincipal.config(menu = menubar)        

# Creamos la Ventana TopLevel
ventanaTop = Toplevel()
ventanaTop.title("Top")

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
        
# Ubicamos el Botón                            
btnCambiar.place(x = 170,y = 350)
                      
# Ejecuta loop
vPrincipal.mainloop()