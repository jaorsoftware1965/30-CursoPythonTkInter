# Curso de Python - Tkinter
# A53 Menu Reference

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A53 Menu Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Creación
# Menu(mb, option, ...)

# Propiedades
# activebackground      The background color that will appear on 
#                       a choice when it is under the mouse.
# activeborderwidth     Specifies the width of a border drawn 
#                       around a choice when it is under the mouse.
#                       Default is 1 pixel.
# activeforeground      The foreground color that will appear on 
#                       a choice when it is under the mouse.
# bg or background      The background color for choices not under 
#                       the mouse.
# bd or borderwidth     The width of the border around all the 
#                       choices. The default is 1 pixel.
# cursor                The cursor that appears when the mouse is
#                       over the choices, but only when the menu 
#                       has been torn off.
# disabledforeground    The color of the text for items whose state
#                       is tk.DISABLED.
# font                  The default font for textual choices.
# fg or foreground      The foreground color used for choices not 
#                       under the mouse.
# postcommand           You can set this option to a procedure, 
#                       and that procedure will be called every 
#                       time someone brings up this menu
# relief                The default 3-D effect for menus is 
#                       relief=tk.RAISED.
# selectcolor           Specifies the color displayed in checkbuttons
#                       and radiobuttons when they are selected.
# tearoff               Normally, a menu can be torn off: the first
#                       position (position 0) in the list of choices
#                       is occupied by the tear-off element, and the 
#                       additional choices
# tearoffcommand        If you would like your program to be notified 
#                       when the user clicks on the tear-off entry
#                       in a menu, set this option to your procedure.
#                       It will be called with two arguments: the 
#                       window ID of the parent window, and the 
#                       window ID of the new tear-off menu's root window
# title                 Normally, the title of a tear-off menu window 
#                       will be the same as the text of the menubutton 
#                       or cascade that lead to this menu. If you want
#                       to change the title of that window, set the title 
#                       option to that string.

# Métodos
# .add(kind, coption, ...)
# Add a new element of the given kind as the next available choice in this menu. The kind argument
# may be any of 'cascade', 'checkbutton', 'command', 'radiobutton', or 'separator'.
# Depending on the kind argument, this method is equivalent to .add_cascade(),

#.add_checkbutton(), and so on; refer to those methods below for details.

# .add_cascade(coption, ...)
# Add a new cascade element as the next available choice in this menu. Use the menu option in this
# call to connect the cascade to the next level's menu, an object of type Menu.

# .add_checkbutton(coption, ...)
# Add a new checkbutton as the next available choice in self. The options allow you to set up the
# checkbutton much the same way as you would set up a Checkbutton object; see Section 15.1, “Menu
# item creation (coption) options” (p. 59).

# .add_command(coption, ...)
# Add a new command as the next available choice in self. Use the label, bitmap, or image option
# to place text or an image on the menu; use the command option to connect this choice to a procedure
# that will be called when this choice is picked.

# .add_radiobutton(coption, ...)
# Add a new radiobutton as the next available choice in self. The options allow you to set up the radiobutton
# in much the same way as you would set up a Radiobutton object; see Section 20, “The
# Radiobutton widget” (p. 68).

# .add_separator()
# Add a separator after the last currently defined option. This is just a ruled horizontal line you can
# use to set off groups of choices. Separators are counted as choices, so if you already have three
# choices, and you add a separator, the separator will occupy position 3 (counting from 0).

# .delete(index1, index2=None)
# This method deletes the choices numbered from index1 through index2, inclusive. To delete one
# choice, omit the index2 argument. You can't use this method to delete a tear-off choice, but you
# can do that by setting the menu object's tearoff option to 0.

# .entrycget(index, coption)
# To retrieve the current value of some coption for a choice, call this method with index set to the
# index of that choice and coption set to the name of the desired option.

# .entryconfigure(index, coption, ...)
# To change the current value of some coption for a choice, call this method with index set to the
# index of that choice and one or more coption=value arguments.

# .index(i)
# Returns the position of the choice specified by index i. For example, you can use .index(tk.END)
# to find the index of the last choice (or None if there are no choices).

# .insert_cascade(index, coption, ...)
# Inserts a new cascade at the position given by index, counting from 0. Any choices after that position
# move down one. The options are the same as for .add_cascade(), above.

# .insert_checkbutton(index, coption, ...)
# Insert a new checkbutton at the position specified by index. Options are the same as for

# .add_checkbutton(), above.

# .insert_command(index, coption, ...)
#Insert a new command at position index. Options are the same as for .add_command(), above.

# .insert_radiobutton(index, coption, ...)
# Insert a new radiobutton at position index. Options are the same as for .add_radiobutton(),
# above.

# .insert_separator(index)
# Insert a new separator at the position specified by index.

# .invoke(index)
# Calls the command callback associated with the choice at position index. If a checkbutton, its state
# is toggled between set and cleared; if a radiobutton, that choice is set.

# .post(x, y)
# Display this menu at position (x, y) relative to the root window.

# .type(index)
# Returns the type of the choice specified by index: either tk.CASCADE, tk.CHECKBUTTON,
# tk.COMMAND, tk.RADIOBUTTON, tk.SEPARATOR, or tk.TEAROFF.

# .yposition(n)
# For the nth menu choice, return the vertical offset in pixels relative to the menu's top. The purpose
# of this method is to allow you to place a popup menu precisely relative to the current mouse position.


# Función que Procesa Menu
def fnProcesaMenu():
   
   print ("Procesando Menu")
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
        filemenu.config(activebackground="green") 
        
    
    if (estado==2):
        filemenu.config(activeborderwidth=15)
       
   
    if (estado==3):       
        filemenu.post(150,150)
         
           
    if (estado==4):       
        filemenu.delete(3)
        
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

                       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 120,y = 120)

# Creamos la barra del Menu en vPrincipal
menubar = Menu(vPrincipal)

# Creamos un Menu para File
filemenu = Menu(menubar, tearoff = 0)

# Crea las opciones
filemenu.add_command(label = "Crear", command = fnProcesaMenu)
filemenu.add_command(label = "Abrir", command = fnProcesaMenu)
filemenu.add_command(label = "Guardar", command = fnProcesaMenu)
filemenu.add_command(label = "Guardar como...", command = fnProcesaMenu)
filemenu.add_command(label = "Cerrar", command = fnProcesaMenu)

# Añade un Separador
filemenu.add_separator()

# Añade la opción Salidaa y la asocia a un comando
filemenu.add_command(label = "Salir", command = vPrincipal.quit)

# Asocia el Menu a la Barra
menubar.add_cascade(label = "Archivo", menu = filemenu)

# Crea el Menu de Edición
editmenu = Menu(menubar, tearoff=0)

# Añade las opciones
editmenu.add_command(label = "Deshacer", command = fnProcesaMenu)

# Añade un separador
editmenu.add_separator()

# Añade mas opciones
editmenu.add_command(label = "Cortar", command = fnProcesaMenu)
editmenu.add_command(label = "Copiar", command = fnProcesaMenu)
editmenu.add_command(label = "Pegar", command = fnProcesaMenu)
editmenu.add_command(label = "Borrar", command = fnProcesaMenu)
editmenu.add_command(label = "Seleccionar todo", command = fnProcesaMenu)

# Añade el Menu a la barra
menubar.add_cascade(label = "Edicion", menu = editmenu)

# Crea el Menu de Ayuda
helpmenu = Menu(menubar, tearoff=0)

# Agrega las opciones
helpmenu.add_command(label = "Help Index", command = fnProcesaMenu)
helpmenu.add_command(label = "About...", command = fnProcesaMenu)

# Agrega el Menu a la Barra
menubar.add_cascade(label = "Ayuda", menu = helpmenu)

# Agrega a la ventana principal la Barra de Menu
vPrincipal.config(menu = menubar)        


# Ejecuta loop
vPrincipal.mainloop()