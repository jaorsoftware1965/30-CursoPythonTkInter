# Curso de Python - Tkinter
# A43 Canvas Text

# Importamos la librería
from tkinter import *
from tkinter import font
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A43 Canvas Text")

# Se establece un tamaño
vPrincipal.geometry("450x450")

# Métodos
# create_text()

# Crea el objeto canvas
xCanvas = Canvas(vPrincipal,   # Ventana Padre
	              bg = "blue",  # Color de Fondo
	              height = 400, # Alto
	              width =400)   # Ancho

# Crea textos en el canvas
# create_text(x, y,options ...)

# Atributos
# activefill      The text color to be used when the text is 
#                 active, that is, when the mouse is over it.
# activestipple   The stipple pattern to be used when the text 
#                 is active. For option values, see stipple below
# anchor          The default is anchor=tk.CENTER, meaning that 
#                 the text is centered vertically and horizontally
#                 around position (x, y).For example, if you 
#                 specify anchor=tk.SW, the text will be positioned
#                 so its lower left corner is at point (x, y).
# disabledfill    The text color to be used when the text object's
#                 state is tk.DISABLED. For option values, see fill
#                 below.
# disabledstipple The stipple pattern to be used when the text is
#                 disabled.
# fill            The default text color is black, but you can 
#                 render it in any color by setting the fill 
#                 option to that color.
# font            If you don't like the default font, set this 
#                 option to any font value
# justify         For multi-line textual displays, this option 
#                 controls how the lines are justified:tk.LEFT 
#                 (the default), tk.CENTER, or tk.RIGHT.
# offset          The stipple offset to be used in rendering the
#                 text
# state           By default, the text item's state is tk.NORMAL.
#                 Set this option to tk.DISABLED to make in 
#                 unresponsive to mouse events, or set it to 
#                 tk.HIDDEN to make it invisible.
# stipple         A bitmap indicating how the text will be 
#                 stippled. Default is stipple='', which means
#                 solid. A typical value would be stipple='gray25'
# tags            If a single string, the text object is tagged 
#                 with that string. Use a tuple of strings to tag
#                 the object with multiple tags
# text            The text to be displayed in the object, as a 
#                 string. Use newline characters ('\n') to force
#                 line breaks
# width           If you don't specify a width option, the text
#                 will be set inside a rectangle as long as the
#                 longest line. However, you can also set the 
#                 width option to a dimension, width and each 
#                 line of the text will be broken into shorter 
#                 lines, if necessary, or even broken within 
#                 words, to fit within the specified width.


# Variable Global
estado = 1

                   
# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):       
       # Creamos un texto
       xCanvas.create_text(100,100, 
                           text = "Python Tkinter")
    
    if (estado==2):       
       oFuente = font.Font(family='Helvetica', 
                           size=12, 
                           weight='bold',
                           slant='italic',
                           underline=1,
                           overstrike=1)
       # Creamos un texto
       xCanvas.create_text(100,100, 
                           anchor = SW,
                           font = oFuente,
                           text = "Python Tkinter")
    
    if (estado==3): 
       oFuente = font.Font(family='Lucida Console', 
                           size=14, 
                           weight='bold',
                           slant='roman',
                           underline=1,
                           overstrike=0)    
       # Creamos un texto
       xCanvas.create_text(100,100,
                           activefill="yellow",       
                           font = oFuente,
                           text = "Python Tkinter")    
            
    # Incremento estado
    estado = estado + 1
    
    if (estado == 4):
       estado = 1

# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                    
# Ubicamos el Botón                            
btnCambiar.place(x = 205,y = 410)
                 
# Agregamos el objeto a la Ventana
xCanvas.pack()

# Ejecuta loop
vPrincipal.mainloop()