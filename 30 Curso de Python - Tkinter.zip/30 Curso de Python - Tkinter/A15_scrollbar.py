# Curso de Python - Tkinter
# A15 scrollbar

# El scrollbar es un objeto que nos permite mostrar una barra de desplazamiento, la cual 
# se encuentra asociada a un objeto desde el cual se controla la visualización del 
# contenido del mismo, cuando este desborda su contenido visual.

# Los objetos a los cuales se les puede colocar un scrollbar son: listbox, Text y canvas
# En esta clase veremos como asociarlo a un ListBox

# Importamos la libreria
from tkinter import *

# Ventana Principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A15 scrollbar")

# Se establece un tamaño
#vPrincipal.geometry("200x100")


# Creamos el ScrollBar
scrollbar = Scrollbar(vPrincipal)

# Insertamos el Scrollbar a la Derecha con Llenado Vertical
scrollbar.pack( side = RIGHT, fill = Y )

# Creamos un LisBox
lstLenguajes = Listbox(vPrincipal,                      # Contenedor
	                   yscrollcommand = scrollbar.set ) # Indica el Scrollbar que controlara

# Agrega elementos al list box
lstLenguajes.insert(0,"C","C++","C#","Java","Python","Pascal","Ruby","php","asp","VB","ASM")

# Agrega el listbox a la ventana principal
lstLenguajes.pack( side = LEFT, fill = BOTH )

# Configura que el control del ScrollBar será por la función yview
scrollbar.config( command = lstLenguajes.yview )

# Cicl Principal
mainloop()