# Curso de Python - Tkinter
# A56 Message Reference

# El Message widget es similar al label, solo que este permite
# desplegar múltiples lineas en el mensaje, y todo el texto será
# desplegado en la misma fuente

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A56 Message Reference")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Constructor
# Message(parent, option, ...)

# Propiedades para option
# aspect                Use this option to specify the ratio of 
#                       width to height as a percentage. For example, 
#                       aspect=100 would give you a text message fit 
#                       into a square;
#                       with aspect=200, the text area would be twice 
#                       as wide as high. The default value is 150, that 
#                       is, the text will be fit into a box 50% wider 
#                       than it is high.
# bg or background      The background color behind the text.
# bd or borderwidth     Width of the border around the widget; 
#                       The default is two pixels. This option is 
#                       visible only when the relief option is not 
#                       tk.FLAT. 
# cursor                Specifies the cursor that appears when the 
#                       mouse is over the widget
# font                  Specifies the font used to display the text 
#                       in the widget
# fg or foreground      Specifies the text color
# highlightbackground   Color of the focus highlight when the widget 
#                       does not have focus
# highlightcolor        Color shown in the focus highlight when the 
#                       widget has the focus.
# highlightthickness    Thickness of the focus highlight
# justify               Use this option to specify how multiple lines
#                       of text are aligned. Use justify=tk.LEFT 
#                       to get a straight left margin; justify=tk.CENTER 
#                       to center each line; and justify=tk.RIGHT to 
#                       get a straight right margin.
# padx                  Use this option to add extra space inside the 
#                       widget to the left and right of the text. The
#                       value is in pixels
# pady                  Use this option to add extra space inside 
#                       the widget above and below the text. The 
#                       value is in pixels.
# relief                This option specifies the appearance of 
#                       the border around the outside of the widget. 
#                       The default style is tk.FLAT.
# takefocus             Normally, a Message widget will not acquire 
#                       focus. Use takefocus=True to add the widget
#                       to the focus traversal list.
# text                  The value of this option is the text to be 
#                       displayed inside the widget.
# textvariable          If you would like to be able to change 
#                       the message under program control, associate 
#                       this option with a StringVar instance. The 
#                       value of this variable is the text to be 
#                       displayed. If you specify both text and 
#                       textvariable options, the text option is ignored.
# width                 Use this option to specify the width of the text 
#                       area in the widget, in pixels. The default width 
#                       depends on the displayed text and the value of 
#                       the aspect option.
   
# Variable Global
estado = 1

# Cambiar la Geometria
def fnCambiarEstado():
    # Indico que variable es global
    global estado
            
    if (estado==1):   
        msgTest.config(aspect=100)    
        msgTest.config(bg="green")    
            
    if (estado==2):
        msgTest.config(aspect=300)
        msgTest.config(fg="black")
           
    if (estado==3):       
        msgTest.config(width=750)
        msgTest.config(justify=CENTER)
         
    if (estado==4):           
        xString.set("Esta es un texto \ncon diversas\nLineas")            
        
    # Incremento estado
    estado = estado + 1
    
    if (estado == 5):
       estado = 1

                       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar",
                    command = fnCambiarEstado)
                 
# Ubicamos el Botón                            
btnCambiar.place(x = 120,y = 120)

# Obtiene una variable
xString = StringVar()

# Coloca el texto a la variable
xString.set("Texto para el Message")

# Creando un Objeto para la Fuente
xFont = ("Helvetica", 10, "bold italic")

# Crea el Objeto Label
msgTest = Message(vPrincipal,              # Objeto Padre
                  textvariable = xString,  # Variable Asociada al Texto
                  font = xFont,            # Establecliendo la Fuente
                  bg="red",                # Color de Fondo
                  fg = "white",            # Color de Texto
                  padx=5,                  # Padx
                  pady=5,                  # Pady
                  relief = GROOVE )        # Tipo de Borde SUNKEN, RAISED, GROOVE, RIDGE, and FLAT

# Coloca en la Ventana Principal
msgTest.pack()


# Ejecuta loop
vPrincipal.mainloop()