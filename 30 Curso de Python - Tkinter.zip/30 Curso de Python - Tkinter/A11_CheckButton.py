# Curso de Python - Tkinter
# A11 CheckButton

# En esta clase veremos el uso del CheckButton; el cual es un objeto que
# se utiliza para indicar un estado de activado o desactivado.

# Variables de control.
# Las variables de control son objetos especiales que se asocian a los widgets para almacenar 
# sus valores y facilitar su disponibilidad en otras partes del programa. Pueden ser de tipo 
# numérico, de cadena y booleano. 

# Cuando una variable de control cambia de valor el widget que la utiliza lo refleja 
# automáticamente, y viceversa. 

# Importamos la librería
from tkinter import *

# Definimos la Ventana Principal    
vPrincipal = Tk()

# Colocamos el Título de la Ventana
vPrincipal.title("11 CheckButton")


# Se define función para controlar el Click en Sonido
def fnOnClickSonido():

    # Despliega el Estado del Botón
    print("Sonido:",CheckVarSonido.get())

# Se define función para controlar el Click en Video
def fnOnClickVideo():

    # Despliega el Estado del Botón
    print("Video:",CheckVarVideo.get())
    
# Definimos 2 variables IntVar para controlar el Estado de los Checkbutton's
CheckVarSonido = IntVar()
CheckVarVideo = IntVar()


# Creamos el CheckButton de Sonido
chkSonido = Checkbutton(vPrincipal, 
                        text = "Sonido", 
                        variable = CheckVarSonido,
                        onvalue = 1, 
                        offvalue = 0, 
                        command = fnOnClickSonido,
                        height=5,
                        width = 20)

# Activa el Check Buttón a através de la variable de Control
CheckVarSonido.set(1)

# Creamos el CheckButton de Video
chkVideo = Checkbutton(vPrincipal, 
                       text = "Video", 
                       variable = CheckVarVideo,
                       onvalue = 1, 
                       offvalue = 0, 
                       height=5,
                       command = fnOnClickVideo,
                       width = 20)

# Agregamos los Checkbuttons a su contenedor                 
chkSonido.pack()
chkVideo.pack()

# El Loop Principal
vPrincipal.mainloop()

# Imprimos los values del Checbutton
print("Estado de los botones al Final")
print(CheckVarSonido.get())
print(CheckVarVideo.get())