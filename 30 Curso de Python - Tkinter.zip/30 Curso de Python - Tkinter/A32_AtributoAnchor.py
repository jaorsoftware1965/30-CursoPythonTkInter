# Curso de Python - Tkinter
# A32 Atributo Anchor

# Importamos la librería
from tkinter import *
    
# Creamos la ventana principal
vPrincipal = Tk()

# Titulo de la Ventana
vPrincipal.title("A32 Atributo Anchor")

# Se establece un tamaño
vPrincipal.geometry("400x200")

# Variable para posicion
posicion = 1

# Valores posibles anchor:
# nw     n     ne
# w    center  e
# sw     s     se 

def fnCambiaPos():
    # Indico que variable es global
    global posicion
            
    if (posicion==1):       
       print("Posición en nw")
       lblMensaje.config(anchor="nw")
              
    if (posicion == 2):  
       print("Posición en n")
       lblMensaje.config(anchor="n")
       
    if (posicion == 3):
       print("Posición en ne")
       lblMensaje.config(anchor="ne")
    
    if (posicion == 4):   
       print("Posición en w")
       lblMensaje.config(anchor="w")
       
    if (posicion == 5):   
       print("Posición en center")
       lblMensaje.config(anchor="center")
       
    if (posicion == 6):   
       print("Posición en e")
       lblMensaje.config(anchor="e")

    if (posicion == 7):   
       print("Posición en sw")
       lblMensaje.config(anchor="sw")

    if (posicion == 8):   
       print("Posición en s")
       lblMensaje.config(anchor="s")

    if (posicion == 9):   
       print("Posición en se")
       lblMensaje.config(anchor="se")              
       
    # Incremento la posicion       
    posicion = posicion + 1
    
    if (posicion == 10):
       posicion = 1
       
# Creamos un botón
btnCambiar = Button(vPrincipal, 
                    text = "Cambiar", 
                    command = fnCambiaPos)

# Ubicamos el Botón                            
btnCambiar.place(x = 0,y = 320)

# Obtiene una variable
xString = StringVar()

# Coloca el texto a la variable
xString.set("Texto en un Label")

# Crea el Objeto Label
lblMensaje = Label(vPrincipal,             # Objeto Padre
                   textvariable = xString, # Variable Asociada al Texto
                   height=200,
                   width=50,
                   anchor="se",
                   bg="blue",              # Color de Fondo
                   relief = RAISED )   

# Coloca la etiqueta                   
lblMensaje.pack()                                    

# Ejecuta loop
vPrincipal.mainloop()