# Curso de Python - Tkinter
# A18 Canvas

# En esta clase veremos el uso del objeto canvas, el cual nos permite realizar acciones
# de dibujo; como en la mayoría de los lenguajes; en los que se maneja este objeto.

# Importamos la librería
from tkinter import *

# Creamos la ventana principal
vPrincipal = Tk()

# Coloca el Título
vPrincipal.title("A18 Canvas")

# Crea el objeto canvas
xCanvas = Canvas(vPrincipal,   # Ventana Padre
	             bg = "blue",  # Color de Fondo
	             height = 400, # Alto
	             width =400)   # Ancho

# Creamos una tupla con las coordenadas
coord = 10, 50, 240, 210
print (coord)
print (type(coord))

# Creamos un arc
arc = xCanvas.create_arc(coord,        # coordenadas
	                     start = 0,    # Incio del arco 
	                     extent = 180, # fin del arco
	                     fill = "red") # color del arco

# Desplegamos el Valor y el tipo
print ("arc id  :",arc)
print ("arc type:",type(arc))

# Dibujamos una línea
line = xCanvas.create_line(10,10,200,200,  # coordenadas
	                       fill = 'white') # color de la linea

# Desplegamos el Valor y el tipo
print ("line id  :",line)
print ("line type:",type(line))

# Dibujamos un cuadrado
cuadrado = xCanvas.create_rectangle(10,150,200,200,  # coordenadas
	                       fill = 'white') # color de la linea

# Desplegamos el Valor y el tipo
print ("cuadrado id  :",cuadrado)
print ("cuadrado type:",type(cuadrado))

# Cargamos una imagen
imgArchivo = PhotoImage(file = "img/jaorsoftware.png")
image = xCanvas.create_image(150, 150,  image = imgArchivo)

# Desplegamos el Valor y el tipo
print ("image id  :",image)
print ("image type:",type(image))

# Agregamos el objeto a la Ventana
xCanvas.pack()

# Ejecutamos loop principal
vPrincipal.mainloop()